import { useCallback, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
    ArrowLeft,
    Download,
    FileText,
    Loader2,
    Mail,
    Phone,
    User,
    Sparkles,
} from "lucide-react";

import AIResumeScore from "../../components/ai/AIResumeScore";
import ATSScore from "../../components/ai/ATSScore";
import SkillMatch from "../../components/ai/SkillMatch";
import MissingSkills from "../../components/ai/MissingSkills";
import RecommendationCard from "../../components/ai/RecommendationCard";
import AISummary from "../../components/ai/AISummary";
import ScheduleInterviewModal from "../../components/interview/ScheduleInterviewModal";
import { ScheduleAIInterviewModal as ScheduleAIInterviewAgentModal } from "../../components/interview/ScheduleAIInterviewModal";

import {
    shortlistCandidate,
    rejectCandidate,
} from "../../services/ai.service";

import {
    getCandidateDetails,
} from "../../services/recruiter.service";

import type { ResumeAnalysis } from "../../types/ai";

interface CandidateDetailsData {
    candidate: { name: string; email: string; phone?: string };
    job: { title: string; company: string };
    status: string;
    resume?: { url: string };
    aiAnalysis: ResumeAnalysis;
}

const CandidateDetails = () => {
    const { applicationId } = useParams();
    const navigate = useNavigate();

    const [loading, setLoading] = useState(true);
    const [actionLoading, setActionLoading] = useState(false);
    const [error, setError] = useState("");
    const [openInterviewModal, setOpenInterviewModal] = useState(false);
    const [openAIInterviewModal, setOpenAIInterviewModal] = useState(false);
    const [candidate, setCandidate] = useState<CandidateDetailsData | null>(null);

    const loadCandidate = useCallback(async () => {
        try {
            setLoading(true);
            const data = await getCandidateDetails(applicationId as string);
            setCandidate(data);
        } catch (err) {
            console.error(err);
            setError("Unable to load candidate.");
        } finally {
            setLoading(false);
        }
    }, [applicationId]);

    useEffect(() => {
        if (applicationId) {
            void loadCandidate();
        }
    }, [applicationId, loadCandidate]);

    const handleShortlist = async () => {
        try {
            setActionLoading(true);
            await shortlistCandidate(applicationId as string);
            alert("Candidate shortlisted successfully.");
            await loadCandidate();
        } catch (err) {
            console.error(err);
            alert("Unable to shortlist candidate.");
        } finally {
            setActionLoading(false);
        }
    };

    const handleReject = async () => {
        try {
            setActionLoading(true);
            await rejectCandidate(applicationId as string);
            alert("Candidate rejected successfully.");
            await loadCandidate();
        } catch (err) {
            console.error(err);
            alert("Unable to reject candidate.");
        } finally {
            setActionLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="flex h-[70vh] items-center justify-center">
                <Loader2 size={40} className="animate-spin text-indigo-600" />
            </div>
        );
    }

    if (error) {
        return (
            <div className="rounded-xl border border-red-200 bg-red-50 p-8">
                <h2 className="text-xl font-semibold text-red-600">{error}</h2>
            </div>
        );
    }

    if (!candidate) return null;

    const analysis = candidate.aiAnalysis as ResumeAnalysis;

    return (
        <div className="space-y-8">
            {/* Back Button */}
            <button
                onClick={() => navigate(-1)}
                className="flex items-center gap-2 text-sm font-medium text-indigo-600 hover:text-indigo-700"
            >
                <ArrowLeft size={18} />
                Back
            </button>

            {/* Candidate Header */}
            <div className="rounded-3xl border border-gray-200 bg-white p-8 shadow-sm">
                <div className="flex flex-col justify-between gap-8 lg:flex-row">
                    <div className="flex gap-6">
                        <div className="flex h-24 w-24 items-center justify-center rounded-full bg-indigo-100">
                            <User size={40} className="text-indigo-600" />
                        </div>

                        <div>
                            <h1 className="text-3xl font-bold text-gray-900">{candidate.candidate.name}</h1>
                            <p className="mt-2 text-lg text-gray-500">{candidate.job.title}</p>
                            <p className="text-sm text-gray-400">{candidate.job.company}</p>

                            <div className="mt-5 flex flex-wrap gap-6">
                                <div className="flex items-center gap-2">
                                    <Mail size={18} className="text-gray-400" />
                                    <span>{candidate.candidate.email}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Phone size={18} className="text-gray-400" />
                                    <span>{candidate.candidate.phone ?? "Not Provided"}</span>
                                </div>
                            </div>

                            <div className="mt-5">
                                <span className="rounded-full bg-indigo-100 px-4 py-2 text-sm font-medium text-indigo-700">
                                    Status : {candidate.status}
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Resume Buttons */}
                    <div className="flex flex-wrap gap-4">
                        {candidate.resume?.url ? (
                            <>
                                <a
                                    href={candidate.resume.url}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="flex items-center gap-2 rounded-xl border border-gray-200 px-5 py-3 transition hover:bg-gray-50"
                                >
                                    <FileText size={18} /> View Resume
                                </a>
                                <a
                                    href={candidate.resume.url}
                                    download
                                    className="flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-white transition hover:bg-indigo-700"
                                >
                                    <Download size={18} /> Download
                                </a>
                            </>
                        ) : (
                            <div className="rounded-xl border border-yellow-300 bg-yellow-50 px-5 py-3 text-yellow-700">
                                Resume Not Uploaded
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* AI Score Cards */}
            <div className="grid gap-6 xl:grid-cols-2">
                <div className="space-y-6">
                    <AIResumeScore score={analysis.overallScore} />
                    <ATSScore score={analysis.atsScore} />
                    <RecommendationCard recommendation={analysis.recommendation} confidence={analysis.overallScore} />
                </div>
                <div className="space-y-6">
                    <SkillMatch skills={analysis.matchedSkills} />
                    <MissingSkills skills={analysis.missingSkills} />
                </div>
            </div>

            {/* AI Summary */}
            <AISummary summary={analysis.summary} strengths={analysis.strengths} improvements={analysis.missingSkills} />

            {/* Experience & Education */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
                    <h2 className="mb-6 text-xl font-semibold">Experience Match</h2>
                    <div className="space-y-5">
                        <div className="flex items-center justify-between">
                            <span className="text-gray-500">Candidate Experience</span>
                            <span className="text-lg font-semibold">{analysis.experience?.candidate ?? 0} Years</span>
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-gray-500">Required Experience</span>
                            <span className="text-lg font-semibold">{analysis.experience?.required ?? 0} Years</span>
                        </div>
                    </div>
                </div>

                <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
                    <h2 className="mb-6 text-xl font-semibold">Education</h2>
                    <div className="rounded-xl bg-gray-50 p-5">
                        <p className="text-lg font-semibold">{analysis.education}</p>
                    </div>
                </div>
            </div>

            {/* Projects */}
            <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
                <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold">Projects Score</h2>
                    <span className="text-3xl font-bold text-indigo-600">{analysis.projectsScore}/5</span>
                </div>
                <div className="mt-6 h-3 overflow-hidden rounded-full bg-gray-200">
                    <div
                        className="h-full rounded-full bg-indigo-600 transition-all duration-500"
                        style={{ width: `${(analysis.projectsScore ?? 0) * 20}%` }}
                    />
                </div>
                <div className="mt-3 flex justify-between text-sm text-gray-500">
                    <span>Poor</span>
                    <span>Excellent</span>
                </div>
            </div>

            {/* Recruiter Actions */}
            <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
                <h2 className="mb-6 text-xl font-semibold">Recruiter Actions</h2>
                <div className="flex flex-wrap gap-4">
                    <button
                        onClick={handleShortlist}
                        disabled={actionLoading}
                        className="rounded-xl bg-emerald-600 px-6 py-3 font-medium text-white hover:bg-emerald-700 disabled:opacity-60"
                    >
                        {actionLoading ? "Processing..." : "Shortlist Candidate"}
                    </button>

                    <button
                        onClick={() => setOpenInterviewModal(true)}
                        className="rounded-xl bg-indigo-600 px-6 py-3 font-medium text-white hover:bg-indigo-700"
                    >
                        Schedule Interview
                    </button>

                    <button
                        onClick={() => setOpenAIInterviewModal(true)}
                        className="rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-3 font-semibold text-white hover:from-blue-500 hover:to-indigo-500 shadow-md transition flex items-center gap-2"
                    >
                        <Sparkles className="h-4 w-4" /> Launch AI Interview Agent
                    </button>

                    <button
                        onClick={handleReject}
                        disabled={actionLoading}
                        className="rounded-xl border border-red-200 bg-red-50 px-6 py-3 font-medium text-red-600 hover:bg-red-100 disabled:opacity-60"
                    >
                        Reject Candidate
                    </button>
                </div>
            </div>

            <ScheduleInterviewModal
                open={openInterviewModal}
                applicationId={applicationId!}
                onClose={() => setOpenInterviewModal(false)}
                onSuccess={loadCandidate}
            />

            <ScheduleAIInterviewAgentModal
                isOpen={openAIInterviewModal}
                applicationId={applicationId!}
                candidateName={candidate.candidate.name}
                jobTitle={candidate.job.title}
                onClose={() => setOpenAIInterviewModal(false)}
                onSuccess={loadCandidate}
            />
        </div>
    );
};

export default CandidateDetails;
