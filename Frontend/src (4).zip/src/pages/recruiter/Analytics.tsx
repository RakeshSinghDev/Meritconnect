export default function Analytics() {
    return (
        <div>
            <h1 className="text-4xl font-bold">
                Recruiter Analytics
            </h1>
        </div>
    );
}