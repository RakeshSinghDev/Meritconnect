import { useEffect, useState } from "react";

import Button from "../../components/ui/Button";

import ApplicationFilters from "../../components/applications/ApplicationFilters";
import EmptyApplications from "../../components/applications/EmptyApplications";
import ApplicationTable from "../../components/applications/ApplicationTable";

import {
    getJobApplications,
    updateApplicationStatus,
} from "../../services/application.service";

import {
    getMyJobs,
} from "../../services/job.service";

import type { Application } from "../../types/application";
import type { Job } from "../../types/job";

const Applications = () => {

    const [jobs, setJobs] = useState<Job[]>([]);

    const [selectedJob, setSelectedJob] =
        useState("");

    const [applications, setApplications] =
        useState<Application[]>([]);

    const [loading, setLoading] =
        useState(true);

    const loadJobs = async () => {

        try {

            const data =
                await getMyJobs();

            setJobs(data);

            if (data.length) {
                setSelectedJob(data[0]._id);
            }

        } catch (err) {

            console.error(err);

        }

    };

    const loadApplications =
        async (jobId: string) => {

            try {

                setLoading(true);

                const data = await getJobApplications(jobId);

                setApplications(data);

            } catch (err) {

                console.error(err);

            } finally {

                setLoading(false);

            }

        };

    useEffect(() => {

        loadJobs();

    }, []);

    useEffect(() => {

        if (selectedJob) {

            loadApplications(selectedJob);

        }

    }, [selectedJob]);

    const changeStatus =
        async (
            applicationId: string,
            status: string
        ) => {

            try {

                await updateApplicationStatus(
                    applicationId,
                    status
                );

                await loadApplications(
                    selectedJob
                );

            } catch (err) {

                console.error(err);

            }

        };

    return (
        <>
            <div className="mb-10 flex items-center justify-between">

                <div>

                    <h1 className="text-4xl font-bold">
                        Applications
                    </h1>

                    <p className="mt-2 text-gray-500">
                        Track every candidate who has applied for your jobs.
                    </p>

                </div>

                <Button>
                    Export
                </Button>

            </div>

            <ApplicationFilters
                jobs={jobs}
                selectedJob={selectedJob}
                onJobChange={setSelectedJob}
            />

            {loading ? (

                <div className="py-12 text-center text-gray-500">
                    Loading applications...
                </div>

            ) : applications.length === 0 ? (

                <EmptyApplications />

            ) : (

                <ApplicationTable
                    applications={applications}
                    onStatusChange={changeStatus}
                />

            )}

        </>
    );

};

export default Applications;
