export default function Candidates() {
    return (
        <div>
            <h1 className="text-4xl font-bold">
                Recruiter Candidates
            </h1>
        </div>
    );
}