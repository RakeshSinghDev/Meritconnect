import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
    getRecruiterAIInterviews,
    cancelAIInterviewSession,
    updateAIInterviewSession,
} from "../../services/aiInterviewAgent.service";
import type { AIInterviewSession } from "../../types/aiInterview";
import { ScheduleAIInterviewModal } from "../../components/interview/ScheduleAIInterviewModal";
import {
    Sparkles,
    Award,
    Search,
    Plus,
    XCircle,
    Calendar,
    Clock,
    User,
    Briefcase,
    Activity,
    Sliders,
    Eye,
    ChevronRight,
    RefreshCw,
    Filter,
} from "lucide-react";
import toast from "react-hot-toast";

const RecruiterAIInterviewsPage: React.FC = () => {
    const navigate = useNavigate();
    const [interviews, setInterviews] = useState<AIInterviewSession[]>([]);
    const [loading, setLoading] = useState(true);
    const [filterText, setFilterText] = useState("");
    const [statusFilter, setStatusFilter] = useState<string>("All");

    // Modal States
    const [isScheduleOpen, setIsScheduleOpen] = useState(false);
    const [rescheduleSession, setRescheduleSession] = useState<AIInterviewSession | null>(null);

    // Reschedule form states
    const [editType, setEditType] = useState<any>("Mixed");
    const [editDifficulty, setEditDifficulty] = useState<any>("Adaptive");
    const [editDuration, setEditDuration] = useState(45);
    const [updating, setUpdating] = useState(false);

    const loadInterviews = async () => {
        setLoading(true);
        try {
            const data = await getRecruiterAIInterviews();
            setInterviews(data || []);
        } catch (err) {
            console.error("Failed to load recruiter interviews:", err);
            toast.error("Failed to load AI interviews");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadInterviews();
    }, []);

    const handleCancel = async (id: string, candidateName?: string) => {
        if (!window.confirm(`Are you sure you want to cancel the AI interview for ${candidateName || "this candidate"}?`)) {
            return;
        }

        try {
            await cancelAIInterviewSession(id);
            toast.success("AI Interview session cancelled.");
            loadInterviews();
        } catch (err: any) {
            toast.error(err.response?.data?.message || "Failed to cancel interview");
        }
    };

    const handleOpenReschedule = (item: AIInterviewSession) => {
        setRescheduleSession(item);
        setEditType(item.type || "Mixed");
        setEditDifficulty(item.config?.difficulty || "Adaptive");
        setEditDuration(item.config?.duration || 45);
    };

    const handleSaveReschedule = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!rescheduleSession) return;

        setUpdating(true);
        try {
            await updateAIInterviewSession(rescheduleSession._id, {
                type: editType,
                config: {
                    difficulty: editDifficulty,
                    duration: editDuration,
                },
            });
            toast.success("Interview session updated!");
            setRescheduleSession(null);
            loadInterviews();
        } catch (err: any) {
            toast.error(err.response?.data?.message || "Failed to update interview");
        } finally {
            setUpdating(false);
        }
    };

    const filtered = interviews.filter((item) => {
        const matchesSearch =
            item.candidate?.name?.toLowerCase().includes(filterText.toLowerCase()) ||
            item.job?.title?.toLowerCase().includes(filterText.toLowerCase());

        const matchesStatus =
            statusFilter === "All" || item.status === statusFilter;

        return matchesSearch && matchesStatus;
    });

    const stats = {
        total: interviews.length,
        completed: interviews.filter((i) => i.status === "Completed").length,
        inProgress: interviews.filter((i) => i.status === "InProgress").length,
        waiting: interviews.filter((i) => i.status === "Waiting").length,
    };

    return (
        <div className="max-w-7xl mx-auto space-y-8 p-6 md:p-10 text-slate-100">
            {/* Header / Hero Bar */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-800/80">
                <div>
                    <div className="flex items-center gap-2.5">
                        <div className="p-2.5 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
                            <Sparkles className="h-6 w-6" />
                        </div>
                        <div>
                            <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-3">
                                AI Interview Dashboard
                            </h1>
                            <p className="text-xs text-slate-400 mt-0.5">
                                Schedule, manage, and review autonomous AI video interview assessments
                            </p>
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-3">
                    <button
                        onClick={loadInterviews}
                        className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 transition"
                        title="Refresh"
                    >
                        <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
                    </button>

                    <button
                        onClick={() => setIsScheduleOpen(true)}
                        className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-blue-500/20 transition flex items-center gap-2"
                    >
                        <Plus className="h-4 w-4" /> Schedule AI Interview
                    </button>
                </div>
            </div>

            {/* Metrics Overview Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                    { label: "Total Sessions", count: stats.total, color: "text-white", border: "border-slate-800" },
                    { label: "Completed", count: stats.completed, color: "text-emerald-400", border: "border-emerald-900/50" },
                    { label: "In Progress", count: stats.inProgress, color: "text-amber-400", border: "border-amber-900/50" },
                    { label: "Awaiting Candidate", count: stats.waiting, color: "text-blue-400", border: "border-blue-900/50" },
                ].map((st, idx) => (
                    <div key={idx} className={`p-4 rounded-2xl bg-slate-900/60 border ${st.border} shadow-lg backdrop-blur-md`}>
                        <p className="text-[11px] font-medium text-slate-400">{st.label}</p>
                        <p className={`text-2xl font-black mt-1 ${st.color}`}>{st.count}</p>
                    </div>
                ))}
            </div>

            {/* Controls Bar: Search & Status Filter */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md">
                {/* Search */}
                <div className="relative w-full sm:w-72">
                    <Search className="h-4 w-4 absolute left-3 top-3 text-slate-500" />
                    <input
                        type="text"
                        value={filterText}
                        onChange={(e) => setFilterText(e.target.value)}
                        placeholder="Search candidate or job title..."
                        className="w-full pl-9 pr-4 py-2 bg-slate-950/80 border border-slate-800 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500 transition"
                    />
                </div>

                {/* Filter Pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
                    {["All", "Waiting", "InProgress", "Completed", "Abandoned"].map((st) => (
                        <button
                            key={st}
                            onClick={() => setStatusFilter(st)}
                            className={`px-3 py-1.5 rounded-xl text-[11px] font-semibold transition shrink-0 ${statusFilter === st
                                ? "bg-blue-600 text-white shadow-md shadow-blue-600/30"
                                : "bg-slate-950/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800/80"
                                }`}
                        >
                            {st === "InProgress" ? "In Progress" : st}
                        </button>
                    ))}
                </div>
            </div>

            {/* Interviews List Grid */}
            {loading ? (
                <div className="flex min-h-[40vh] items-center justify-center text-slate-400">
                    <Sparkles className="h-6 w-6 text-blue-400 animate-spin mr-2" />
                    <span className="text-xs font-medium">Loading AI Interviews...</span>
                </div>
            ) : filtered.length === 0 ? (
                <div className="p-12 text-center bg-slate-900/40 rounded-3xl border border-slate-800 text-slate-400 space-y-3">
                    <Sparkles className="h-8 w-8 text-slate-600 mx-auto" />
                    <p className="text-sm font-semibold text-slate-300">No AI Interviews match your criteria</p>
                    <p className="text-xs text-slate-500">Schedule an interview for an applicant to get started.</p>
                    <button
                        onClick={() => setIsScheduleOpen(true)}
                        className="px-4 py-2 rounded-xl bg-blue-600/20 border border-blue-500/30 text-blue-400 text-xs font-bold hover:bg-blue-600/30 transition inline-flex items-center gap-2 mt-2"
                    >
                        <Plus className="h-4 w-4" /> Schedule Interview
                    </button>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {filtered.map((item) => {
                        const isCompleted = item.status === "Completed";
                        const isInProgress = item.status === "InProgress";
                        const isWaiting = item.status === "Waiting";
                        const isAbandoned = item.status === "Abandoned";

                        return (
                            <div
                                key={item._id}
                                className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800/90 space-y-5 shadow-xl hover:border-slate-700/90 transition backdrop-blur-md flex flex-col justify-between group"
                            >
                                <div className="space-y-4">
                                    {/* Top Status & Format Badges */}
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            <span className="px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[11px] font-semibold tracking-wide">
                                                {item.type}
                                            </span>
                                            <span className="text-[10px] text-slate-500 font-mono">
                                                {item.config?.duration || 45} min
                                            </span>
                                        </div>

                                        {/* Dynamic Status Badge */}
                                        <div className="flex items-center gap-2">
                                            {isInProgress && (
                                                <span className="relative flex h-2 w-2">
                                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                                                    <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                                                </span>
                                            )}
                                            <span
                                                className={`text-[10px] font-extrabold uppercase tracking-wider px-3 py-1 rounded-full border ${isCompleted
                                                    ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                                                    : isInProgress
                                                        ? "bg-amber-500/10 text-amber-400 border-amber-500/30"
                                                        : isAbandoned
                                                            ? "bg-rose-500/10 text-rose-400 border-rose-500/30"
                                                            : "bg-blue-500/10 text-blue-400 border-blue-500/30"
                                                    }`}
                                            >
                                                {item.status}
                                            </span>
                                        </div>
                                    </div>

                                    {/* Candidate & Job Info */}
                                    <div>
                                        <h3 className="font-bold text-base text-white group-hover:text-blue-400 transition flex items-center gap-2">
                                            <User className="h-4 w-4 text-slate-400 shrink-0" />
                                            {item.candidate?.name || "Candidate"}
                                        </h3>
                                        <p className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                                            <Briefcase className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                                            Application for <strong className="text-slate-200">{item.job?.title || "Role"}</strong>
                                        </p>
                                    </div>

                                    {/* Score / Progress Card */}
                                    {isCompleted && item.report?.overallScore !== undefined ? (
                                        <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
                                            <div>
                                                <p className="text-[10px] uppercase font-bold text-slate-400">Recommendation</p>
                                                <p className="text-sm font-black text-emerald-400 mt-0.5">
                                                    {item.report.hiringRecommendation}
                                                </p>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-[10px] uppercase font-bold text-slate-400">Overall Score</p>
                                                <p className="text-2xl font-black text-white">{item.report.overallScore}<span className="text-xs font-normal text-slate-500">/100</span></p>
                                            </div>
                                        </div>
                                    ) : isInProgress ? (
                                        <div className="p-3.5 rounded-2xl bg-amber-950/20 border border-amber-800/40 text-xs text-amber-300 space-y-1">
                                            <div className="flex items-center justify-between font-medium">
                                                <span className="flex items-center gap-1.5">
                                                    <Activity className="h-3.5 w-3.5 animate-pulse" /> Live Interview Active
                                                </span>
                                                <span className="font-mono text-[11px]">{item.questions?.length || 0} Questions</span>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="p-3.5 rounded-2xl bg-slate-950/40 border border-slate-800/60 text-xs text-slate-400">
                                            <p className="text-[11px]">Interview code sent to candidate. Awaiting candidate login.</p>
                                        </div>
                                    )}
                                </div>

                                {/* Actions Bar */}
                                <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-2">
                                    <div className="flex items-center gap-2">
                                        {(isWaiting || isAbandoned) && (
                                            <button
                                                onClick={() => handleOpenReschedule(item)}
                                                className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition"
                                                title="Reschedule / Edit Config"
                                            >
                                                <Sliders className="h-3.5 w-3.5 text-blue-400" />
                                                <span className="hidden sm:inline">Reschedule</span>
                                            </button>
                                        )}

                                        {isWaiting && (
                                            <button
                                                onClick={() => handleCancel(item._id, item.candidate?.name)}
                                                className="p-2 rounded-xl bg-slate-950 hover:bg-rose-950/50 border border-slate-800 hover:border-rose-800/50 text-slate-400 hover:text-rose-400 text-xs font-semibold transition"
                                                title="Cancel Session"
                                            >
                                                <XCircle className="h-3.5 w-3.5" />
                                                <span className="hidden sm:inline">Cancel</span>
                                            </button>
                                        )}
                                    </div>

                                    {/* Primary CTA */}
                                    <button
                                        onClick={() => navigate(`/recruiter/ai-interviews/${item._id}/report`)}
                                        className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 transition ml-auto"
                                    >
                                        <Award className="h-4 w-4" />
                                        <span>{isCompleted ? "View Report & Transcript" : "View Details"}</span>
                                        <ChevronRight className="h-3.5 w-3.5 opacity-70" />
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}

            {/* Schedule New Interview Modal */}
            <ScheduleAIInterviewModal
                isOpen={isScheduleOpen}
                onClose={() => setIsScheduleOpen(false)}
                onSuccess={loadInterviews}
            />

            {/* Reschedule / Edit Config Modal */}
            {rescheduleSession && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
                    <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-6 shadow-2xl space-y-5 text-slate-100">
                        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                            <h3 className="font-bold text-base flex items-center gap-2">
                                <Sliders className="h-4 w-4 text-blue-400" /> Reschedule / Reconfigure Session
                            </h3>
                            <button onClick={() => setRescheduleSession(null)} className="text-slate-400 hover:text-white">
                                <XCircle className="h-5 w-5" />
                            </button>
                        </div>

                        <form onSubmit={handleSaveReschedule} className="space-y-4 text-xs">
                            <div>
                                <label className="block text-slate-400 mb-1 font-semibold">Format</label>
                                <select
                                    value={editType}
                                    onChange={(e) => setEditType(e.target.value)}
                                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 font-medium outline-none"
                                >
                                    <option value="Mixed">Mixed</option>
                                    <option value="Technical">Technical</option>
                                    <option value="Behavioral">Behavioral</option>
                                    <option value="Coding">Coding</option>
                                    <option value="SystemDesign">System Design</option>
                                    <option value="ResumeDeepDive">Resume Deep Dive</option>
                                </select>
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="block text-slate-400 mb-1 font-semibold">Difficulty</label>
                                    <select
                                        value={editDifficulty}
                                        onChange={(e) => setEditDifficulty(e.target.value)}
                                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 font-medium outline-none"
                                    >
                                        <option value="Adaptive">Adaptive AI</option>
                                        <option value="Easy">Easy</option>
                                        <option value="Medium">Medium</option>
                                        <option value="Hard">Hard</option>
                                    </select>
                                </div>

                                <div>
                                    <label className="block text-slate-400 mb-1 font-semibold">Duration (Min)</label>
                                    <input
                                        type="number"
                                        value={editDuration}
                                        onChange={(e) => setEditDuration(Number(e.target.value))}
                                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 font-medium outline-none"
                                        min={15}
                                        max={90}
                                    />
                                </div>
                            </div>

                            <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-800">
                                <button
                                    type="button"
                                    onClick={() => setRescheduleSession(null)}
                                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={updating}
                                    className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-lg"
                                >
                                    {updating ? "Saving..." : "Save & Reschedule"}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default RecruiterAIInterviewsPage;