export default function Settings() {
    return (
        <div>
            <h1 className="text-4xl font-bold">
                Recruiter Settings
            </h1>
        </div>
    );
}