export default function CandidateSettings() {
    return (
        <div className="space-y-6 text-slate-100">
            <div>
                <h1 className="text-3xl font-extrabold">Candidate Settings</h1>
                <p className="text-xs text-slate-400 mt-1">Manage your account preferences and notification settings.</p>
            </div>
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
                <p className="font-semibold text-slate-200">Account Preferences</p>
                <p className="mt-1 text-slate-400">Settings and notification configuration options.</p>
            </div>
        </div>
    );
}
