import { useEffect, useState } from "react";
import toast from "react-hot-toast";

import ResumeUpload from "../../components/candidate/ResumeUpload";

import {
    getCurrentUser,
    updateCurrentUser,
} from "../../services/user.service";

interface ProfileForm {
    name: string;
    bio: string;
    phone: string;
    location: string;
    college: string;
    education: string;
    experience: number;
    currentCompany: string;
    currentPosition: string;
    github: string;
    linkedin: string;
    portfolio: string;
    skills: string;
}

const Profile = () => {

    const [loading, setLoading] = useState(true);

    const [saving, setSaving] = useState(false);

    const [profile, setProfile] =
        useState<ProfileForm>({
            name: "",
            bio: "",
            phone: "",
            location: "",
            college: "",
            education: "",
            experience: 0,
            currentCompany: "",
            currentPosition: "",
            github: "",
            linkedin: "",
            portfolio: "",
            skills: "",
        });

    useEffect(() => {

        const loadProfile = async () => {

            try {

                const user =
                    await getCurrentUser();

                setProfile({
                    name: user.name || "",

                    bio:
                        user.profile?.bio || "",

                    phone:
                        user.profile?.phone || "",

                    location:
                        user.profile?.location || "",

                    college:
                        user.profile?.college || "",

                    education:
                        user.profile?.education ||
                        "",

                    experience:
                        user.profile
                            ?.experience || 0,

                    currentCompany:
                        user.profile
                            ?.currentCompany || "",

                    currentPosition:
                        user.profile
                            ?.currentPosition || "",

                    github:
                        user.profile?.github ||
                        "",

                    linkedin:
                        user.profile
                            ?.linkedin || "",

                    portfolio:
                        user.profile
                            ?.portfolio || "",

                    skills:
                        user.profile?.skills
                            ?.join(", ") || "",
                });

            } catch {

                toast.error(
                    "Failed to load profile."
                );

            } finally {

                setLoading(false);

            }

        };

        loadProfile();

    }, []);

    const handleChange = (
        e: React.ChangeEvent<
            HTMLInputElement | HTMLTextAreaElement
        >
    ) => {

        const {
            name,
            value,
        } = e.target;

        setProfile((prev) => ({
            ...prev,
            [name]:
                name === "experience"
                    ? Number(value)
                    : value,
        }));

    };

    const handleSubmit = async (
        e: React.FormEvent
    ) => {

        e.preventDefault();

        try {

            setSaving(true);

            await updateCurrentUser(profile);

            toast.success(
                "Profile updated successfully."
            );

        } catch {

            toast.error(
                "Failed to update profile."
            );

        } finally {

            setSaving(false);

        }

    };

    if (loading) {

        return (
            <div className="flex h-96 items-center justify-center">
                Loading profile...
            </div>
        );

    }

    return (
        <div className="space-y-8">

            <ResumeUpload />

            <div>

                <h1 className="text-4xl font-bold">
                    My Profile
                </h1>

                <p className="mt-2 text-gray-500">
                    Manage your profile information.
                </p>

            </div>

            <form
                onSubmit={handleSubmit}
                className="rounded-2xl border bg-white p-8"
            >

                <div className="grid gap-6 md:grid-cols-2">

                    <div>

                        <label className="mb-2 block font-medium">
                            Full Name
                        </label>

                        <input
                            name="name"
                            value={profile.name}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div>

                        <label className="mb-2 block font-medium">
                            Phone
                        </label>

                        <input
                            name="phone"
                            value={profile.phone}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div>

                        <label className="mb-2 block font-medium">
                            Location
                        </label>

                        <input
                            name="location"
                            value={profile.location}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div>

                        <label className="mb-2 block font-medium">
                            College
                        </label>

                        <input
                            name="college"
                            value={profile.college}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div>

                        <label className="mb-2 block font-medium">
                            Education
                        </label>

                        <input
                            name="education"
                            value={profile.education}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div>

                        <label className="mb-2 block font-medium">
                            Experience (Years)
                        </label>

                        <input
                            type="number"
                            name="experience"
                            value={profile.experience}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div>

                        <label className="mb-2 block font-medium">
                            Current Company
                        </label>

                        <input
                            name="currentCompany"
                            value={profile.currentCompany}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div>

                        <label className="mb-2 block font-medium">
                            Current Position
                        </label>

                        <input
                            name="currentPosition"
                            value={profile.currentPosition}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div>

                        <label className="mb-2 block font-medium">
                            GitHub
                        </label>

                        <input
                            name="github"
                            value={profile.github}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div>

                        <label className="mb-2 block font-medium">
                            LinkedIn
                        </label>

                        <input
                            name="linkedin"
                            value={profile.linkedin}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div className="md:col-span-2">

                        <label className="mb-2 block font-medium">
                            Portfolio
                        </label>

                        <input
                            name="portfolio"
                            value={profile.portfolio}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div className="md:col-span-2">

                        <label className="mb-2 block font-medium">
                            Bio
                        </label>

                        <textarea
                            rows={4}
                            name="bio"
                            value={profile.bio}
                            onChange={handleChange}
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                    <div className="md:col-span-2">

                        <label className="mb-2 block font-medium">
                            Skills
                        </label>

                        <textarea
                            rows={5}
                            name="skills"
                            value={profile.skills}
                            onChange={handleChange}
                            placeholder="React, Node.js, MongoDB..."
                            className="w-full rounded-xl border p-3"
                        />

                    </div>

                </div>

                <button
                    type="submit"
                    disabled={saving}
                    className="mt-8 rounded-xl bg-black px-8 py-3 text-white transition hover:bg-gray-800 disabled:opacity-50"
                >
                    {saving
                        ? "Saving..."
                        : "Save Profile"}
                </button>

            </form>

        </div>
    );
};

export default Profile;