import { useEffect, useState } from "react";
import {
    BriefcaseBusiness,
    FileText,
    Trophy,
    Brain,
    Calendar,
    Clock,
    Video,
    MapPin,
} from "lucide-react";

import {
    getCandidateInterviews,
} from "../../services/interview.service";

import type { Interview } from "../../types/interview";

import { getCandidateDashboard } from "../../services/candidate.service";

interface RecentApplication {
    applicationId: string;
    jobTitle: string;
    company: string;
    status: string;
    atsScore: number;
}

interface CandidateDashboardData {
    totalApplications: number;
    interview: number;
    hired: number;
    averageATSScore: number;
    recentApplications: RecentApplication[];
}

const Dashboard = () => {
    const [dashboard, setDashboard] = useState<CandidateDashboardData | null>(null);
    const [loading, setLoading] = useState(true);

    const [interviews, setInterviews] =
        useState<Interview[]>([]);

    useEffect(() => {
        const loadDashboard = async () => {
            try {
                const [
                    dashboardData,
                    interviewData,
                ] = await Promise.all([
                    getCandidateDashboard(),
                    getCandidateInterviews(),
                ]);

                setDashboard(dashboardData);

                setInterviews(interviewData);
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        loadDashboard();
    }, []);

    if (loading) {
        return (
            <div className="flex h-96 items-center justify-center">
                Loading Dashboard...
            </div>
        );
    }

    if (!dashboard) {
        return (
            <div className="flex h-96 items-center justify-center">
                Failed to load dashboard.
            </div>
        );
    }

    const cards = [
        {
            title: "Applications",
            value: dashboard.totalApplications,
            icon: FileText,
        },
        {
            title: "Interviews",
            value: dashboard.interview,
            icon: BriefcaseBusiness,
        },
        {
            title: "Hired",
            value: dashboard.hired,
            icon: Trophy,
        },
        {
            title: "Average ATS",
            value: `${dashboard.averageATSScore}%`,
            icon: Brain,
        },
    ];

    return (
        <div className="space-y-8">

            <div>
                <h1 className="text-4xl font-bold">
                    Candidate Dashboard
                </h1>

                <p className="mt-2 text-gray-500">
                    Welcome back. Here's your progress.
                </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">

                {cards.map((card) => {

                    const Icon = card.icon;

                    return (

                        <div
                            key={card.title}
                            className="rounded-2xl border border-gray-200 bg-white p-6"
                        >

                            <div className="flex items-center justify-between">

                                <div>

                                    <p className="text-sm text-gray-500">
                                        {card.title}
                                    </p>

                                    <h2 className="mt-2 text-3xl font-bold">
                                        {card.value}
                                    </h2>

                                </div>

                                <div className="rounded-xl bg-black p-3 text-white">
                                    <Icon size={24} />
                                </div>

                            </div>

                        </div>

                    );

                })}

            </div>

            <div className="rounded-2xl border border-gray-200 bg-white p-6">

                <h2 className="mb-5 text-xl font-semibold">
                    Recent Applications
                </h2>

                {dashboard.recentApplications.length === 0 ? (

                    <p className="text-gray-500">
                        No applications yet.
                    </p>

                ) : (

                    <div className="space-y-4">

                        {dashboard.recentApplications.map((item) => (

                            <div
                                key={item.applicationId}
                                className="flex items-center justify-between rounded-xl border p-4"
                            >

                                <div>

                                    <h3 className="font-semibold">
                                        {item.jobTitle}
                                    </h3>

                                    <p className="text-sm text-gray-500">
                                        {item.company}
                                    </p>

                                </div>

                                <div className="text-right">

                                    <p className="font-medium">
                                        {item.status}
                                    </p>

                                    <p className="text-sm text-gray-500">
                                        ATS {item.atsScore}%
                                    </p>

                                </div>

                            </div>

                        ))}

                    </div>

                )}

            </div>

            {/* Upcoming Interviews */}

            <div className="rounded-2xl border border-gray-200 bg-white p-6">

                <h2 className="mb-6 text-xl font-semibold">

                    Upcoming Interviews

                </h2>

                {interviews.length === 0 ? (

                    <p className="text-gray-500">

                        No interviews scheduled.

                    </p>

                ) : (

                    <div className="space-y-5">

                        {interviews
                            .filter(
                                (i) => i.status === "Scheduled"
                            )
                            .map((interview) => (

                                <div
                                    key={interview._id}
                                    className="rounded-xl border border-gray-200 p-5"
                                >

                                    <div className="flex flex-col justify-between gap-5 lg:flex-row">

                                        <div>

                                            <h3 className="text-lg font-semibold">

                                                {interview.job.title}

                                            </h3>

                                            <p className="text-gray-500">

                                                {interview.job.company}

                                            </p>

                                            <div className="mt-4 flex flex-wrap gap-4 text-sm text-gray-600">

                                                <span className="flex items-center gap-2">

                                                    <Calendar size={16} />

                                                    {new Date(
                                                        interview.interviewDate
                                                    ).toLocaleString([], {
                                                        dateStyle: "medium",
                                                        timeStyle: "short",
                                                    })}

                                                </span>

                                                <span className="flex items-center gap-2">

                                                    <Clock size={16} />

                                                    {new Date(
                                                        interview.interviewDate
                                                    ).toLocaleTimeString([], {
                                                        hour: "2-digit",
                                                        minute: "2-digit",
                                                    })}

                                                </span>

                                            </div>

                                        </div>

                                        <div className="flex flex-col gap-3">

                                            {interview.mode ===
                                                "Online" ? (

                                                <a
                                                    href={interview.meetingLink ?? "#"}
                                                    target="_blank"
                                                    rel="noreferrer"
                                                    className="flex items-center justify-center gap-2 rounded-xl bg-black px-5 py-3 text-white"
                                                >

                                                    <Video size={18} />

                                                    Join Meeting

                                                </a>

                                            ) : (

                                                <div className="flex items-center gap-2 rounded-xl border px-5 py-3">

                                                    <MapPin size={18} />

                                                    {interview.venue}

                                                </div>

                                            )}

                                            <span className="rounded-full bg-green-100 px-4 py-2 text-center text-sm font-medium text-green-700">

                                                {interview.status}

                                            </span>

                                        </div>

                                    </div>

                                </div>

                            ))}

                    </div>

                )}

            </div>

        </div>
    );
};

export default Dashboard;
