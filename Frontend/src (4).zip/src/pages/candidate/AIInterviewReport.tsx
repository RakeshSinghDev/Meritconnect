import React, { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAIInterviewStore } from "../../store/useAIInterviewStore";
import { InterviewReport } from "../../components/ai-interview/InterviewReport";
import { ArrowLeft, Sparkles, Download, Printer } from "lucide-react";

export const AIInterviewReportPage: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const { session, fetchSession, report } = useAIInterviewStore();

    useEffect(() => {
        if (id) fetchSession(id);
    }, [id]);

    if (!session) {
        return (
            <div className="flex min-h-screen items-center justify-center bg-slate-950 text-slate-300">
                <div className="flex items-center gap-3">
                    <Sparkles className="h-6 w-6 text-blue-400 animate-spin" />
                    <span>Retrieving Interview Evaluation Report...</span>
                </div>
            </div>
        );
    }

    const handleDownloadPDF = () => {
        if (report?.pdfUrl && report.pdfUrl.startsWith("http")) {
            window.open(report.pdfUrl, "_blank");
        } else {
            window.print();
        }
    };

    return (
        <div className="min-h-screen bg-slate-950 text-slate-100 p-6 md:p-12 print:bg-white print:p-0 print:text-black">
            {/* Header */}
            <div className="max-w-5xl mx-auto flex items-center justify-between pb-6 mb-6 border-b border-slate-800 print:hidden">
                <button
                    onClick={() => navigate("/candidate/ai-interviews")}
                    className="flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-slate-200 transition"
                >
                    <ArrowLeft className="h-4 w-4" /> Back to My AI Interviews
                </button>

                <button
                    onClick={handleDownloadPDF}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-blue-500/20 transition"
                >
                    <Download className="h-4 w-4" /> Download PDF Report
                </button>
            </div>

            <InterviewReport session={session} report={report} />
        </div>
    );
};

export default AIInterviewReportPage;
