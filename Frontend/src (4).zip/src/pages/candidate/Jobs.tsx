import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
    BriefcaseBusiness,
    Clock,
    MapPin,
} from "lucide-react";

import { getJobs } from "../../services/job.service";
import type { Job } from "../../types/job";

const CandidateJobs = () => {
    const navigate = useNavigate();

    const [jobs, setJobs] = useState<Job[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    const loadJobs = async () => {
        try {
            setLoading(true);

            const data = await getJobs();

            setJobs(data);
        } catch (err) {
            console.error(err);

            setError("Failed to load jobs.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadJobs();
    }, []);

    if (loading) {
        return (
            <div className="flex h-80 items-center justify-center">
                Loading jobs...
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex h-80 items-center justify-center text-red-500">
                {error}
            </div>
        );
    }

    if (jobs.length === 0) {
        return (
            <div className="rounded-3xl border border-dashed border-gray-300 bg-white py-20 text-center">
                <BriefcaseBusiness
                    size={50}
                    className="mx-auto mb-4 text-gray-400"
                />

                <h2 className="text-2xl font-semibold">
                    No jobs available
                </h2>

                <p className="mt-3 text-gray-500">
                    Please check again later.
                </p>
            </div>
        );
    }

    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-3xl font-bold">
                    Available Jobs
                </h1>

                <p className="mt-2 text-gray-500">
                    Find the best opportunity for your career.
                </p>
            </div>

            <div className="grid gap-6">
                {jobs.map((job) => (
                    <div
                        key={job._id}
                        className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm"
                    >
                        <div className="flex items-start justify-between">
                            <div>
                                <h2 className="text-xl font-semibold">
                                    {job.title}
                                </h2>

                                <p className="mt-1 text-gray-500">
                                    {job.company}
                                </p>
                            </div>
                        </div>

                        <div className="mt-4 flex flex-wrap gap-5 text-sm text-gray-500">
                            <span className="flex items-center gap-2">
                                <MapPin size={16} />
                                {job.location}
                            </span>

                            <span className="flex items-center gap-2">
                                <Clock size={16} />
                                {job.employmentType}
                            </span>

                            <span>
                                {job.salary}
                            </span>
                        </div>

                        <p className="mt-5 line-clamp-3 text-gray-600">
                            {job.description}
                        </p>

                        <button
                            onClick={() =>
                                navigate(
                                    `/candidate/jobs/${job._id}`
                                )
                            }
                            className="mt-6 rounded-xl bg-black px-5 py-2 text-white hover:bg-gray-800"
                        >
                            View Details
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default CandidateJobs;
