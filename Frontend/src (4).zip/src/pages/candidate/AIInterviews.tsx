import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getCandidateAIInterviews } from "../../services/aiInterviewAgent.service";
import type { AIInterviewSession } from "../../types/aiInterview";
import {
    Sparkles,
    Calendar,
    Clock,
    Award,
    Play,
    CheckCircle2,
    XCircle,
    Activity,
    ChevronRight,
    Search,
    RefreshCw,
    TrendingUp,
    Shield,
    FileText,
    ArrowUpRight,
} from "lucide-react";

export const AIInterviewsPage: React.FC = () => {
    const navigate = useNavigate();
    const [interviews, setInterviews] = useState<AIInterviewSession[]>([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<"all" | "upcoming" | "completed" | "missed">("all");
    const [searchQuery, setSearchQuery] = useState("");

    const loadInterviews = async () => {
        setLoading(true);
        try {
            const data = await getCandidateAIInterviews();
            setInterviews(data || []);
        } catch (err) {
            console.error("Error loading candidate AI interviews:", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadInterviews();
    }, []);

    // Filter categorization
    const upcomingList = interviews.filter((i) => i.status === "Waiting" || i.status === "InProgress");
    const completedList = interviews.filter((i) => i.status === "Completed");
    const missedList = interviews.filter((i) => i.status === "Abandoned" || i.status === "Expired");

    const filtered = interviews.filter((item) => {
        const matchesSearch =
            item.job?.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.job?.company?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.type?.toLowerCase().includes(searchQuery.toLowerCase());

        if (!matchesSearch) return false;

        if (activeTab === "upcoming") return item.status === "Waiting" || item.status === "InProgress";
        if (activeTab === "completed") return item.status === "Completed";
        if (activeTab === "missed") return item.status === "Abandoned" || item.status === "Expired";
        return true;
    });

    return (
        <div className="max-w-7xl mx-auto space-y-8 p-6 md:p-10 text-slate-100 animate-in fade-in duration-300">
            {/* Top Hero Section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-800/80">
                <div className="space-y-1">
                    <div className="flex items-center gap-2.5">
                        <div className="p-2.5 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
                            <Sparkles className="h-6 w-6" />
                        </div>
                        <div>
                            <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-3">
                                Candidate AI Interview Portal
                            </h1>
                            <p className="text-xs text-slate-400">
                                Practice, join scheduled AI interviewer rounds, and view your performance analytics
                            </p>
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-3">
                    <button
                        onClick={loadInterviews}
                        className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 transition"
                        title="Refresh list"
                    >
                        <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
                    </button>
                </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                    { label: "Total Invitations", count: interviews.length, color: "text-white", border: "border-slate-800" },
                    { label: "Upcoming / Active", count: upcomingList.length, color: "text-blue-400", border: "border-blue-900/50" },
                    { label: "Completed", count: completedList.length, color: "text-emerald-400", border: "border-emerald-900/50" },
                    { label: "Missed / Expired", count: missedList.length, color: "text-slate-400", border: "border-slate-800" },
                ].map((st, idx) => (
                    <div key={idx} className={`p-4 rounded-2xl bg-slate-900/60 border ${st.border} shadow-lg backdrop-blur-md`}>
                        <p className="text-[11px] font-medium text-slate-400">{st.label}</p>
                        <p className={`text-2xl font-black mt-1 ${st.color}`}>{st.count}</p>
                    </div>
                ))}
            </div>

            {/* Navigation Tabs & Search */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md">
                {/* Search */}
                <div className="relative w-full sm:w-72">
                    <Search className="h-4 w-4 absolute left-3 top-3 text-slate-500" />
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search by job title or company..."
                        className="w-full pl-9 pr-4 py-2 bg-slate-950/80 border border-slate-800 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500 transition"
                    />
                </div>

                {/* Filter Tabs */}
                <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
                    {[
                        { id: "all", label: `All (${interviews.length})` },
                        { id: "upcoming", label: `Upcoming (${upcomingList.length})` },
                        { id: "completed", label: `Completed (${completedList.length})` },
                        { id: "missed", label: `Missed (${missedList.length})` },
                    ].map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id as any)}
                            className={`px-3.5 py-1.5 rounded-xl text-[11px] font-semibold transition shrink-0 ${activeTab === tab.id
                                ? "bg-blue-600 text-white shadow-md shadow-blue-600/30"
                                : "bg-slate-950/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800/80"
                                }`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>
            </div>

            {/* SKELETON LOADING STATE */}
            {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {[1, 2, 3, 4].map((i) => (
                        <div key={i} className="p-6 rounded-3xl bg-slate-900/40 border border-slate-800/80 space-y-4 animate-pulse">
                            <div className="flex justify-between items-center">
                                <div className="h-5 w-24 bg-slate-800 rounded-full" />
                                <div className="h-5 w-20 bg-slate-800 rounded-full" />
                            </div>
                            <div className="h-6 w-3/4 bg-slate-800 rounded-lg" />
                            <div className="h-4 w-1/2 bg-slate-800/60 rounded-lg" />
                            <div className="h-10 w-full bg-slate-800/40 rounded-xl" />
                        </div>
                    ))}
                </div>
            ) : filtered.length === 0 ? (
                /* EMPTY STATE */
                <div className="p-12 text-center bg-slate-900/40 rounded-3xl border border-slate-800 text-slate-400 space-y-3">
                    <Sparkles className="h-8 w-8 text-slate-600 mx-auto" />
                    <p className="text-sm font-semibold text-slate-300">
                        {activeTab === "upcoming"
                            ? "No upcoming AI interviews scheduled"
                            : activeTab === "completed"
                                ? "No completed AI interviews yet"
                                : "No AI interviews found"}
                    </p>
                    <p className="text-xs text-slate-500 max-w-sm mx-auto">
                        When recruiters invite you for an AI interview round, your session invitation and waiting room link will appear here.
                    </p>
                </div>
            ) : (
                /* INTERVIEWS GRID */
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {filtered.map((item) => {
                        const isCompleted = item.status === "Completed";
                        const isInProgress = item.status === "InProgress";
                        const isWaiting = item.status === "Waiting";
                        const isMissed = item.status === "Abandoned" || item.status === "Expired";

                        return (
                            <div
                                key={item._id}
                                className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800/90 space-y-5 shadow-xl hover:border-slate-700/90 transition backdrop-blur-md flex flex-col justify-between group"
                            >
                                <div className="space-y-4">
                                    {/* Format & Status Header */}
                                    <div className="flex items-center justify-between">
                                        <span className="px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[11px] font-semibold tracking-wide">
                                            {item.type} Round
                                        </span>

                                        <div className="flex items-center gap-2">
                                            {isInProgress && (
                                                <span className="relative flex h-2 w-2">
                                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                                                    <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                                                </span>
                                            )}
                                            <span
                                                className={`text-[10px] font-extrabold uppercase tracking-wider px-3 py-1 rounded-full border ${isCompleted
                                                    ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                                                    : isInProgress
                                                        ? "bg-amber-500/10 text-amber-400 border-amber-500/30"
                                                        : isMissed
                                                            ? "bg-rose-500/10 text-rose-400 border-rose-500/30"
                                                            : "bg-blue-500/10 text-blue-400 border-blue-500/30"
                                                    }`}
                                            >
                                                {isWaiting ? "Scheduled / Ready" : item.status}
                                            </span>
                                        </div>
                                    </div>

                                    {/* Job Title & Company */}
                                    <div>
                                        <h3 className="font-bold text-base text-white group-hover:text-blue-400 transition">
                                            {item.job?.title || "Software Engineer Role"}
                                        </h3>
                                        <p className="text-xs text-slate-400 mt-1">
                                            {item.job?.company || "Recruiting Company"}
                                        </p>
                                    </div>

                                    {/* Meta Details & Config */}
                                    <div className="flex items-center gap-4 text-xs text-slate-400 font-mono">
                                        <span className="flex items-center gap-1.5">
                                            <Clock className="h-3.5 w-3.5 text-blue-400 shrink-0" />
                                            {item.config?.duration || 45} Min
                                        </span>
                                        <span className="flex items-center gap-1.5">
                                            <Calendar className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                                            {new Date(item.createdAt).toLocaleDateString()}
                                        </span>
                                        <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-[10px] text-slate-300">
                                            {item.config?.difficulty || "Adaptive"}
                                        </span>
                                    </div>

                                    {/* STATUS TIMELINE BAR */}
                                    <div className="pt-2">
                                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">Interview Lifecycle</p>
                                        <div className="flex items-center gap-1.5 text-[10px] font-medium">
                                            <div className={`px-2.5 py-1 rounded-lg border ${isWaiting || isInProgress || isCompleted ? "bg-blue-950/60 border-blue-800/80 text-blue-300" : "bg-slate-950 border-slate-800 text-slate-500"}`}>
                                                1. Invitation
                                            </div>
                                            <ChevronRight className="h-3 w-3 text-slate-600 shrink-0" />
                                            <div className={`px-2.5 py-1 rounded-lg border ${isInProgress || isCompleted ? "bg-amber-950/60 border-amber-800/80 text-amber-300" : "bg-slate-950 border-slate-800 text-slate-500"}`}>
                                                2. Live Session
                                            </div>
                                            <ChevronRight className="h-3 w-3 text-slate-600 shrink-0" />
                                            <div className={`px-2.5 py-1 rounded-lg border ${isCompleted ? "bg-emerald-950/60 border-emerald-800/80 text-emerald-300" : "bg-slate-950 border-slate-800 text-slate-500"}`}>
                                                3. Evaluation Report
                                            </div>
                                        </div>
                                    </div>

                                    {/* AI Score Badge (If Completed) */}
                                    {isCompleted && item.report?.overallScore !== undefined && (
                                        <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
                                            <div>
                                                <p className="text-[10px] font-bold uppercase text-slate-400">AI Assessment Result</p>
                                                <p className="text-sm font-black text-emerald-400 mt-0.5">
                                                    {item.report.hiringRecommendation}
                                                </p>
                                            </div>
                                            <div className="text-right font-mono">
                                                <p className="text-[10px] font-bold uppercase text-slate-400">Score</p>
                                                <p className="text-2xl font-black text-white">{item.report.overallScore}<span className="text-xs text-slate-500 font-normal">/100</span></p>
                                            </div>
                                        </div>
                                    )}
                                </div>

                                {/* Bottom Action Button */}
                                <div className="pt-4 border-t border-slate-800/80">
                                    {isCompleted ? (
                                        <button
                                            onClick={() => navigate(`/candidate/ai-interviews/${item._id}/report`)}
                                            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition"
                                        >
                                            <Award className="h-4 w-4 text-emerald-400" />
                                            <span>View My Evaluation & Scores</span>
                                        </button>
                                    ) : isMissed ? (
                                        <button
                                            disabled
                                            className="w-full py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-500 text-xs font-semibold flex items-center justify-center gap-2 cursor-not-allowed opacity-60"
                                        >
                                            <XCircle className="h-4 w-4 text-rose-500" />
                                            <span>Interview Session Expired / Cancelled</span>
                                        </button>
                                    ) : (
                                        <button
                                            onClick={() => navigate(`/candidate/ai-interviews/${item._id}/waiting`)}
                                            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 transition"
                                        >
                                            <Play className="h-4 w-4 fill-white" />
                                            <span>Join Interview Waiting Room</span>
                                        </button>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};

export default AIInterviewsPage;
