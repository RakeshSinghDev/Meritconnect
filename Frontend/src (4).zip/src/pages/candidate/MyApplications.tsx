import { useEffect, useState } from "react";
import { getCandidateApplications } from "../../services/candidate.service";

interface Application {
    applicationId: string;
    jobTitle: string;
    company: string;
    location: string;
    employmentType: string;
    salary: string;
    status: string;
    atsScore: number;
    appliedAt: string;
}

const MyApplications = () => {
    const [applications, setApplications] = useState<Application[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadApplications = async () => {
            try {
                const data = await getCandidateApplications();
                setApplications(data);
            } catch (error) {
                console.error(error);
            } finally {
                setLoading(false);
            }
        };

        loadApplications();
    }, []);

    if (loading) {
        return (
            <div className="flex h-96 items-center justify-center">
                Loading Applications...
            </div>
        );
    }

    return (
        <div className="space-y-8">

            <div>
                <h1 className="text-4xl font-bold">
                    My Applications
                </h1>

                <p className="mt-2 text-gray-500">
                    Track every application you've submitted.
                </p>
            </div>

            {applications.length === 0 ? (

                <div className="rounded-2xl border border-dashed border-gray-300 bg-white py-20 text-center">

                    <h2 className="text-2xl font-semibold">
                        No Applications Found
                    </h2>

                    <p className="mt-3 text-gray-500">
                        Start applying to jobs.
                    </p>

                </div>

            ) : (

                <div className="space-y-5">

                    {applications.map((application) => (

                        <div
                            key={application.applicationId}
                            className="rounded-2xl border border-gray-200 bg-white p-6"
                        >

                            <div className="flex items-center justify-between">

                                <div>

                                    <h2 className="text-xl font-semibold">
                                        {application.jobTitle}
                                    </h2>

                                    <p className="mt-1 text-gray-500">
                                        {application.company}
                                    </p>

                                    <div className="mt-4 flex flex-wrap gap-6 text-sm text-gray-500">

                                        <span>
                                            📍 {application.location}
                                        </span>

                                        <span>
                                            💼 {application.employmentType}
                                        </span>

                                        <span>
                                            💰 {application.salary}
                                        </span>

                                    </div>

                                </div>

                                <div className="text-right">

                                    <span className="rounded-full bg-blue-100 px-4 py-2 text-sm font-medium text-blue-700">
                                        {application.status}
                                    </span>

                                    <p className="mt-3 text-sm text-gray-500">
                                        ATS Score
                                    </p>

                                    <h3 className="text-2xl font-bold">
                                        {application.atsScore}%
                                    </h3>

                                </div>

                            </div>

                            <div className="mt-5 border-t pt-4 text-sm text-gray-500">
                                Applied on{" "}
                                {new Date(
                                    application.appliedAt
                                ).toLocaleDateString()}
                            </div>

                        </div>

                    ))}

                </div>

            )}

        </div>
    );
};

export default MyApplications;