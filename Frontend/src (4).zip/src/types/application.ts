export interface Application {
    _id: string;
    id: string;

    jobId: string;

    candidateName: string;

    email: string;

    phone: string;

    resume: string;

    score: number;

    status:
    | "Pending"
    | "Reviewed"
    | "Shortlisted"
    | "Rejected";

    appliedAt: string;
}