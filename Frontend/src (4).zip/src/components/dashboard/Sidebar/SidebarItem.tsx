import { NavLink } from "react-router-dom";
import type { LucideIcon } from "lucide-react";

interface SidebarItemProps {
    to: string;
    icon: LucideIcon;
    label: string;
}

const SidebarItem = ({ to, icon: Icon, label }: SidebarItemProps) => {
    return (
        <NavLink
            to={to}
            className={({ isActive }) =>
                `group flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-all duration-200
                ${isActive
                    ? "bg-black text-white shadow-sm"
                    : "text-gray-600 hover:bg-gray-100 hover:text-black"
                }`
            }
        >
            <Icon size={20} strokeWidth={2} />
            <span>{label}</span>
        </NavLink>
    );
};

export default SidebarItem;