import {
    LayoutDashboard,
    BriefcaseBusiness,
    FileText,
    User,
    Bot,
    Settings,
    LogOut,
} from "lucide-react";

import SidebarItem from "../dashboard/Sidebar/SidebarItem";
import { useAuth } from "../../store/AuthContext";
import { useNavigate } from "react-router-dom";

const menuItems = [
    {
        label: "Dashboard",
        icon: LayoutDashboard,
        path: "/candidate/dashboard",
    },
    {
        label: "Jobs",
        icon: BriefcaseBusiness,
        path: "/candidate/jobs",
    },
    {
        label: "My Applications",
        icon: FileText,
        path: "/candidate/applications",
    },
    {
        label: "AI Interviews",
        icon: Bot,
        path: "/candidate/ai-interviews",
    },
    {
        label: "Profile",
        icon: User,
        path: "/candidate/profile",
    },
    {
        label: "Settings",
        icon: Settings,
        path: "/candidate/settings",
    },
];

const CandidateSidebar = () => {
    const navigate = useNavigate();

    const {
        user,
        logoutUser,
    } = useAuth();

    const handleLogout = async () => {
        await logoutUser();

        navigate("/login");
    };

    return (
        <aside className="sticky top-0 flex h-screen w-72 flex-col border-r border-gray-200 bg-white">

            {/* Logo */}

            <div className="border-b border-gray-100 px-6 py-6">

                <h1 className="text-2xl font-bold tracking-tight">
                    Merit
                    <span className="text-gray-500">
                        Connect
                    </span>
                </h1>

                <p className="mt-1 text-sm text-gray-500">
                    Candidate Workspace
                </p>

            </div>

            {/* Navigation */}

            <nav className="flex-1 space-y-2 p-4">

                {menuItems.map((item) => (

                    <SidebarItem
                        key={item.path}
                        to={item.path}
                        icon={item.icon}
                        label={item.label}
                    />

                ))}

            </nav>

            {/* User */}

            <div className="border-t border-gray-100 p-4">

                <div className="mb-4 flex items-center gap-3 rounded-xl border border-gray-200 p-3">

                    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-black text-sm font-semibold text-white">
                        {user?.name?.charAt(0)}
                    </div>

                    <div>

                        <h3 className="text-sm font-semibold">
                            {user?.name}
                        </h3>

                        <p className="text-xs text-gray-500">
                            Candidate
                        </p>

                    </div>

                </div>

                <button
                    onClick={handleLogout}
                    className="flex w-full items-center justify-center gap-2 rounded-xl border border-gray-200 py-3 text-sm font-medium transition hover:bg-red-50 hover:text-red-600"
                >

                    <LogOut size={18} />

                    Logout

                </button>

            </div>

        </aside>
    );
};

export default CandidateSidebar;