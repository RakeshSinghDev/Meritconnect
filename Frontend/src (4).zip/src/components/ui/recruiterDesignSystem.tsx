import React from "react";
import { Link } from "react-router-dom";
import {
    Plus,
    Calendar,
    ArrowUpRight,
    CheckCircle2,
    Clock,
    User,
    ChevronRight,
    Activity,
    Bell,
    Video,
    Sparkles,
    FileText,
    ExternalLink,
} from "lucide-react";

/* -------------------------------------------------------------------------- */
/* CARD PRIMITIVE                                                             */
/* -------------------------------------------------------------------------- */
export const Card: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = "" }) => (
    <div className={`rounded-2xl bg-slate-900/70 border border-slate-800/80 p-6 shadow-xl backdrop-blur-md transition-all duration-200 hover:border-slate-700/80 ${className}`}>
        {children}
    </div>
);

/* -------------------------------------------------------------------------- */
/* METRIC CARD PRIMITIVE                                                      */
/* -------------------------------------------------------------------------- */
export interface MetricCardProps {
    title: string;
    value: string | number;
    subtext?: string;
    trend?: { label: string; positive?: boolean };
    icon?: React.ElementType;
}

export const MetricCard: React.FC<MetricCardProps> = ({ title, value, subtext, trend, icon: Icon }) => (
    <div className="rounded-2xl bg-slate-900/70 border border-slate-800/80 p-5 shadow-lg backdrop-blur-md transition hover:border-slate-700/80 flex flex-col justify-between space-y-3">
        <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{title}</span>
            {Icon && <Icon className="h-4 w-4 text-slate-500" />}
        </div>
        <div className="space-y-1">
            <div className="text-3xl font-black tracking-tight text-white">{value}</div>
            {subtext && <p className="text-[11px] font-medium text-slate-500">{subtext}</p>}
        </div>
        {trend && (
            <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                <ArrowUpRight className="h-3 w-3" />
                <span>{trend.label}</span>
            </div>
        )}
    </div>
);

/* -------------------------------------------------------------------------- */
/* STATUS BADGE PRIMITIVE                                                     */
/* -------------------------------------------------------------------------- */
export const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
    const normalized = (status || "").toLowerCase();
    let style = "bg-slate-800 text-slate-300 border-slate-700";

    if (normalized.includes("hired") || normalized.includes("completed")) {
        style = "bg-emerald-950/60 text-emerald-300 border-emerald-800/60";
    } else if (normalized.includes("interview") || normalized.includes("shortlisted")) {
        style = "bg-blue-950/60 text-blue-300 border-blue-800/60";
    } else if (normalized.includes("screening") || normalized.includes("reviewed")) {
        style = "bg-purple-950/60 text-purple-300 border-purple-800/60";
    } else if (normalized.includes("rejected") || normalized.includes("abandoned")) {
        style = "bg-rose-950/60 text-rose-300 border-rose-800/60";
    }

    return (
        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${style}`}>
            {status}
        </span>
    );
};

/* -------------------------------------------------------------------------- */
/* SECTION HEADER PRIMITIVE                                                   */
/* -------------------------------------------------------------------------- */
export const SectionHeader: React.FC<{ title: string; subtitle?: string; action?: React.ReactNode }> = ({
    title,
    subtitle,
    action,
}) => (
    <div className="flex items-center justify-between pb-2 mb-4 border-b border-slate-800/80">
        <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">{title}</h2>
            {subtitle && <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>}
        </div>
        {action}
    </div>
);

/* -------------------------------------------------------------------------- */
/* HORIZONTAL HIRING PIPELINE COMPONENT                                       */
/* -------------------------------------------------------------------------- */
export interface PipelineStage {
    name: string;
    count: number;
    percentage: number;
}

export const HiringPipeline: React.FC<{ stages: PipelineStage[] }> = ({ stages }) => (
    <div className="space-y-4">
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {stages.map((stage, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-2">
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        <span>{stage.name}</span>
                        <span className="text-slate-500 font-mono">{stage.percentage}%</span>
                    </div>
                    <div className="text-2xl font-black text-white">{stage.count}</div>
                    {/* Minimal Progress Bar */}
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                        <div
                            className="h-full bg-slate-200 rounded-full transition-all duration-500"
                            style={{ width: `${Math.min(100, Math.max(5, stage.percentage))}%` }}
                        />
                    </div>
                </div>
            ))}
        </div>
    </div>
);

/* -------------------------------------------------------------------------- */
/* TODAY'S SCHEDULE COMPONENT                                                 */
/* -------------------------------------------------------------------------- */
export interface ScheduleItem {
    id: string;
    candidateName: string;
    jobTitle: string;
    time: string;
    type: string;
    status: string;
}

export const TodaySchedule: React.FC<{ items: ScheduleItem[]; onScheduleNew: () => void }> = ({ items, onScheduleNew }) => (
    <div className="space-y-4">
        <SectionHeader
            title="Today's Schedule & Timeline"
            subtitle="Upcoming AI Video Interviews & Evaluations"
            action={
                <button
                    onClick={onScheduleNew}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white text-slate-950 hover:bg-slate-200 text-xs font-bold transition shadow-sm"
                >
                    <Plus className="h-3.5 w-3.5" /> Schedule Session
                </button>
            }
        />

        {items.length === 0 ? (
            <div className="p-8 text-center bg-slate-950/60 rounded-2xl border border-slate-800/80 space-y-2">
                <Calendar className="h-6 w-6 text-slate-600 mx-auto" />
                <p className="text-xs font-bold text-slate-300">No Interviews Scheduled Today</p>
                <p className="text-[11px] text-slate-500">Schedule an AI Video Interview to evaluate candidates autonomously.</p>
            </div>
        ) : (
            <div className="space-y-3">
                {items.map((item) => (
                    <div
                        key={item.id}
                        className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between gap-4 transition hover:border-slate-700"
                    >
                        <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-center text-slate-300 font-bold text-xs shrink-0">
                                {item.candidateName.charAt(0)}
                            </div>
                            <div>
                                <h4 className="text-xs font-bold text-white">{item.candidateName}</h4>
                                <p className="text-[11px] text-slate-400">{item.jobTitle}</p>
                            </div>
                        </div>

                        <div className="flex items-center gap-3">
                            <div className="text-right hidden sm:block">
                                <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                                    <Clock className="h-3 w-3" /> {item.time}
                                </span>
                                <StatusBadge status={item.status} />
                            </div>

                            <Link
                                to={item.status === "Completed" ? `/recruiter/ai-interviews/report/${item.id}` : `/candidate/ai-interviews/waiting/${item.id}`}
                                className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-bold transition flex items-center gap-1"
                            >
                                {item.status === "Completed" ? (
                                    <>
                                        <FileText className="h-3 w-3" /> Report
                                    </>
                                ) : (
                                    <>
                                        <Video className="h-3 w-3" /> Join Room
                                    </>
                                )}
                            </Link>
                        </div>
                    </div>
                ))}
            </div>
        )}
    </div>
);

/* -------------------------------------------------------------------------- */
/* RECENT ACTIVITY LOG                                                        */
/* -------------------------------------------------------------------------- */
export interface ActivityItem {
    id: string;
    title: string;
    timestamp: string;
    type: "application" | "interview" | "status";
}

export const RecentActivityFeed: React.FC<{ items: ActivityItem[] }> = ({ items }) => (
    <div className="space-y-4">
        <SectionHeader title="Live Activity Feed" subtitle="Real-time recruitment stream" />
        <div className="space-y-3">
            {items.map((act) => (
                <div key={act.id} className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400">
                            {act.type === "interview" ? (
                                <Sparkles className="h-3.5 w-3.5 text-blue-400" />
                            ) : act.type === "status" ? (
                                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                            ) : (
                                <User className="h-3.5 w-3.5 text-slate-400" />
                            )}
                        </div>
                        <span className="font-semibold text-slate-200">{act.title}</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 shrink-0">{act.timestamp}</span>
                </div>
            ))}
        </div>
    </div>
);
