import React, { useState } from "react";
import type { AIInterviewReport, AIInterviewSession } from "../../types/aiInterview";
import {
    Award,
    CheckCircle2,
    AlertTriangle,
    FileText,
    Sparkles,
    MessageSquare,
    Code2,
    Activity,
    ChevronDown,
    ChevronUp,
    HelpCircle,
    Info,
} from "lucide-react";

interface InterviewReportProps {
    session: AIInterviewSession;
    report?: AIInterviewReport | null;
}

export const InterviewReport: React.FC<InterviewReportProps> = ({ session, report: propReport }) => {
    const report = propReport || session.report;
    const [activeTab, setActiveTab] = useState<"overview" | "explanations" | "transcript" | "coding" | "telemetry">("overview");
    const [expandedQuestion, setExpandedQuestion] = useState<number | null>(null);
    const [selectedScoreExpl, setSelectedScoreExpl] = useState<string | null>(null);

    if (!report) {
        return (
            <div className="flex flex-col items-center justify-center p-12 text-center bg-slate-900/60 rounded-3xl border border-slate-800 text-slate-400 space-y-3">
                <Sparkles className="h-10 w-10 text-blue-400 animate-spin" />
                <h3 className="text-lg font-bold text-white">Generating Comprehensive AI Evaluation Report...</h3>
                <p className="text-xs text-slate-500 max-w-sm">
                    Gemini is processing candidate answers, transcript nuances, code complexity, and behavioral telemetry.
                </p>
            </div>
        );
    }

    const recommendationConfig = {
        "Strong Hire": { color: "from-emerald-600 to-teal-700 text-white border-emerald-500/30", badge: "bg-emerald-400 text-slate-950" },
        "Hire": { color: "from-emerald-600/90 to-emerald-800 text-white border-emerald-500/30", badge: "bg-emerald-400 text-slate-950" },
        "Lean Hire": { color: "from-blue-600 to-indigo-700 text-white border-blue-500/30", badge: "bg-blue-400 text-slate-950" },
        "Lean No Hire": { color: "from-amber-600 to-orange-700 text-white border-amber-500/30", badge: "bg-amber-400 text-slate-950" },
        "No Hire": { color: "from-rose-600 to-red-800 text-white border-rose-500/30", badge: "bg-rose-400 text-slate-950" },
        "Pending": { color: "from-slate-700 to-slate-800 text-slate-200 border-slate-700", badge: "bg-slate-500 text-white" },
    }[report.hiringRecommendation || "Pending"];

    const scoreDimensions = [
        { key: "technicalScore", label: "Technical Knowledge", score: report.technicalScore ?? 80, color: "text-blue-400" },
        { key: "communicationScore", label: "Communication", score: report.communicationScore ?? 80, color: "text-emerald-400" },
        { key: "confidenceScore", label: "Confidence", score: report.confidenceScore ?? 80, color: "text-indigo-400" },
        { key: "problemSolvingScore", label: "Problem Solving", score: report.problemSolvingScore ?? 80, color: "text-purple-400" },
        { key: "codingScore", label: "Coding Execution", score: report.codingScore ?? 80, color: "text-cyan-400" },
        { key: "behaviorScore", label: "Behavior & Maturity", score: report.behaviorScore ?? 80, color: "text-teal-400" },
        { key: "grammarScore", label: "Grammar & Syntax", score: report.grammarScore ?? 85, color: "text-amber-400" },
        { key: "vocabularyScore", label: "Domain Vocabulary", score: report.vocabularyScore ?? 85, color: "text-indigo-300" },
        { key: "leadershipScore", label: "Leadership & Initiative", score: report.leadershipScore ?? 75, color: "text-emerald-300" },
        { key: "systemDesignScore", label: "System Design", score: report.systemDesignScore ?? 80, color: "text-blue-300" },
    ];

    const explanationsMap = report.scoreExplanations || {};

    return (
        <div className="max-w-5xl mx-auto space-y-8 text-slate-100 print:text-black print:max-w-full">
            {/* Top Recommendation Hero Banner */}
            <div className={`p-8 rounded-3xl bg-gradient-to-br ${recommendationConfig.color} shadow-2xl border relative overflow-hidden print:bg-white print:border-black print:text-black`}>
                <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                    <div className="space-y-2">
                        <div className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-widest opacity-80">
                            <Award className="h-4 w-4 shrink-0" /> AI Executive Evaluation Report
                        </div>
                        <div className="flex items-center gap-3">
                            <h1 className="text-3xl font-black tracking-tight">
                                {report.hiringRecommendation}
                            </h1>
                            <span className={`text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full ${recommendationConfig.badge}`}>
                                Final Assessment
                            </span>
                        </div>
                        <p className="text-xs opacity-90 pt-1">
                            Candidate: <strong className="font-bold underline">{session.candidate?.name}</strong> &bull; Position:{" "}
                            <strong className="font-bold">{session.job?.title}</strong>
                        </p>
                    </div>

                    {/* Overall Score Circle */}
                    <div className="flex items-center gap-4 bg-black/25 backdrop-blur-md px-6 py-4 rounded-2xl border border-white/20 shrink-0 print:border-black">
                        <div className="text-center">
                            <div className="text-4xl font-black tracking-tight">{report.overallScore}</div>
                            <div className="text-[10px] font-extrabold uppercase tracking-wider opacity-80">Overall Score</div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Navigation Tabs (Hidden in Print) */}
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3 overflow-x-auto print:hidden">
                {[
                    { id: "overview", label: "Executive Scores", icon: FileText },
                    { id: "explanations", label: "Detailed Score Explanations", icon: Info },
                    { id: "transcript", label: `Transcript (${session.transcript?.length || 0})`, icon: MessageSquare },
                    { id: "coding", label: `Coding Submissions (${session.codingChallenges?.length || 0})`, icon: Code2 },
                    { id: "telemetry", label: "Behavioral Telemetry", icon: Activity },
                ].map((tab) => {
                    const Icon = tab.icon;
                    return (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id as any)}
                            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition shrink-0 ${activeTab === tab.id
                                ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30"
                                : "bg-slate-900/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800/80"
                                }`}
                        >
                            <Icon className="h-4 w-4" />
                            <span>{tab.label}</span>
                        </button>
                    );
                })}
            </div>

            {/* TAB 1: EXECUTIVE OVERVIEW & SCORE GRID */}
            {(activeTab === "overview" || window.matchMedia("print").matches) && (
                <div className="space-y-8">
                    {/* 10 Score Dimensions Grid */}
                    <div>
                        <div className="flex items-center justify-between mb-3">
                            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                                <Sparkles className="h-3.5 w-3.5 text-blue-400" /> Multi-Dimensional Assessment (10 Criteria)
                            </h3>
                            <span className="text-[10px] text-slate-500">Click any card to view detailed explanation</span>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                            {scoreDimensions.map((item) => (
                                <div
                                    key={item.key}
                                    onClick={() => {
                                        setSelectedScoreExpl(selectedScoreExpl === item.key ? null : item.key);
                                        setActiveTab("explanations");
                                    }}
                                    className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800/80 shadow-lg backdrop-blur-md hover:border-blue-500/50 transition cursor-pointer group print:bg-white print:border-slate-300"
                                >
                                    <p className="text-[11px] font-semibold text-slate-400 group-hover:text-blue-300 transition print:text-slate-700">
                                        {item.label}
                                    </p>
                                    <div className="flex items-baseline gap-1 mt-1.5">
                                        <span className={`text-xl font-black ${item.color} print:text-black`}>{item.score}</span>
                                        <span className="text-[10px] text-slate-500">/ 100</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Key Strengths & Growth Areas */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800/80 shadow-xl space-y-4 backdrop-blur-md print:bg-white print:border-slate-300">
                            <div className="flex items-center gap-2 font-bold text-emerald-400 text-xs uppercase tracking-wider">
                                <CheckCircle2 className="h-4 w-4" /> Demonstrated Key Strengths
                            </div>
                            <ul className="space-y-2.5">
                                {(report.strengths || []).map((str, i) => (
                                    <li key={i} className="flex items-start gap-2.5 text-xs text-slate-300 print:text-slate-800">
                                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                                        <span>{str}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800/80 shadow-xl space-y-4 backdrop-blur-md print:bg-white print:border-slate-300">
                            <div className="flex items-center gap-2 font-bold text-rose-400 text-xs uppercase tracking-wider">
                                <AlertTriangle className="h-4 w-4" /> Growth & Probe Areas
                            </div>
                            <ul className="space-y-2.5">
                                {(report.weaknesses || []).map((wk, i) => (
                                    <li key={i} className="flex items-start gap-2.5 text-xs text-slate-300 print:text-slate-800">
                                        <span className="h-1.5 w-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                                        <span>{wk}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>

                    {/* Detailed Analysis */}
                    <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800/80 shadow-xl space-y-3 backdrop-blur-md print:bg-white print:border-slate-300">
                        <div className="flex items-center gap-2 font-bold text-blue-400 text-xs uppercase tracking-wider">
                            <FileText className="h-4 w-4" /> Detailed Executive Analysis
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line print:text-slate-800">
                            {report.detailedAnalysis}
                        </p>
                    </div>
                </div>
            )}

            {/* TAB 2: DETAILED SCORE EXPLANATIONS */}
            {activeTab === "explanations" && (
                <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800/80 shadow-xl space-y-6 backdrop-blur-md">
                    <div className="pb-3 border-b border-slate-800">
                        <h3 className="font-bold text-sm text-white flex items-center gap-2">
                            <Info className="h-4 w-4 text-blue-400" /> AI Score Rationale & Evidence
                        </h3>
                        <p className="text-xs text-slate-400 mt-0.5">
                            Detailed rationale citing transcript evidence for every score dimension.
                        </p>
                    </div>

                    <div className="space-y-4">
                        {scoreDimensions.map((item) => {
                            const explanationText =
                                explanationsMap[item.key] ||
                                `Candidate demonstrated a score of ${item.score}/100 in ${item.label} based on their responses, vocabulary usage, and technical depth during the interview.`;

                            const isSelected = selectedScoreExpl === item.key;

                            return (
                                <div
                                    key={item.key}
                                    className={`p-4 rounded-2xl border text-xs space-y-2 transition ${isSelected
                                        ? "bg-blue-950/40 border-blue-500/50 shadow-lg"
                                        : "bg-slate-950/60 border-slate-800/80"
                                        }`}
                                >
                                    <div className="flex items-center justify-between font-bold">
                                        <span className="text-slate-200 text-xs flex items-center gap-2">
                                            <span className={`text-base ${item.color}`}>{item.score}</span>
                                            <span>{item.label}</span>
                                        </span>
                                        <span className="text-[10px] text-slate-500 font-mono">100 Max</span>
                                    </div>
                                    <p className="text-slate-300 leading-relaxed">{explanationText}</p>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* TAB 3: TRANSCRIPT */}
            {activeTab === "transcript" && (
                <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800/80 shadow-xl space-y-4 backdrop-blur-md">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                        <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-blue-400">
                            <MessageSquare className="h-4 w-4" /> Speech-to-Text Conversation Log
                        </div>
                        <span className="text-xs text-slate-400">{session.transcript?.length || 0} Turn Exchanges</span>
                    </div>

                    <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                        {(session.transcript || []).map((t, idx) => {
                            const isInterviewer = t.role === "interviewer";
                            return (
                                <div
                                    key={idx}
                                    className={`flex items-start gap-3 text-xs ${isInterviewer ? "justify-start" : "justify-end"}`}
                                >
                                    <div
                                        className={`max-w-2xl p-4 rounded-2xl border space-y-1 ${isInterviewer
                                            ? "bg-slate-950/80 border-slate-800 text-slate-200"
                                            : "bg-blue-950/40 border-blue-800/60 text-blue-100"
                                            }`}
                                    >
                                        <div className="flex items-center justify-between text-[10px] text-slate-400 font-semibold mb-1">
                                            <span>{isInterviewer ? "Alex (AI Interviewer)" : session.candidate?.name || "Candidate"}</span>
                                            <span>{new Date(t.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                        </div>
                                        <p className="leading-relaxed whitespace-pre-wrap">{t.content}</p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* TAB 4: CODING SUBMISSIONS */}
            {activeTab === "coding" && (
                <div className="space-y-6">
                    {session.codingChallenges?.length === 0 ? (
                        <div className="p-12 text-center bg-slate-900/60 rounded-3xl border border-slate-800 text-slate-400">
                            <Code2 className="h-8 w-8 text-slate-600 mx-auto mb-2" />
                            <p className="text-sm font-semibold">No Coding Challenges Administered</p>
                            <p className="text-xs text-slate-500">This interview session was configured without an interactive coding round.</p>
                        </div>
                    ) : (
                        (session.codingChallenges || []).map((challenge, idx) => (
                            <div key={idx} className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800/80 shadow-xl space-y-4 backdrop-blur-md">
                                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                                    <div>
                                        <h4 className="font-bold text-sm text-white">{challenge.title}</h4>
                                        <p className="text-xs text-slate-400 mt-0.5">{challenge.description}</p>
                                    </div>
                                    <span className="px-3 py-1 rounded-full bg-purple-950 border border-purple-800 text-purple-300 text-[10px] font-mono font-bold uppercase">
                                        {challenge.language || "javascript"}
                                    </span>
                                </div>

                                <div className="space-y-2">
                                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Candidate Code Solution</p>
                                    <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-400 overflow-x-auto">
                                        <code>{challenge.candidateCode || "// No code submitted."}</code>
                                    </pre>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            )}

            {/* TAB 5: TELEMETRY */}
            {activeTab === "telemetry" && (
                <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800/80 shadow-xl space-y-6 backdrop-blur-md">
                    <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-blue-400 pb-3 border-b border-slate-800">
                        <Activity className="h-4 w-4" /> Candidate Behavioral & Telemetry Metrics
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
                        <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                            <p className="text-slate-400">Eye Contact Score</p>
                            <p className="text-2xl font-black text-emerald-400 mt-1">{session.metrics?.eyeContactScore ?? 95}%</p>
                        </div>
                        <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                            <p className="text-slate-400">Overall Engagement</p>
                            <p className="text-2xl font-black text-blue-400 mt-1">{session.metrics?.overallEngagement ?? 92}%</p>
                        </div>
                        <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                            <p className="text-slate-400">Filler Words Count</p>
                            <p className="text-2xl font-black text-amber-400 mt-1">{session.metrics?.fillerWords?.count ?? 2}</p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
