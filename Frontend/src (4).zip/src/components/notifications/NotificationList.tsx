import { useEffect, useState } from "react";
import {
    Bell,
    Check,
    Trash2,
} from "lucide-react";

import {
    deleteNotification,
    getNotifications,
    markAllAsRead,
    markAsRead,
} from "../../services/notification.service";

import type {
    Notification,
} from "../../types/notification";

const NotificationList = () => {

    const [notifications, setNotifications] =
        useState<Notification[]>([]);

    const [loading, setLoading] =
        useState(true);

    const loadNotifications = async () => {

        try {

            setLoading(true);

            const data =
                await getNotifications();

            setNotifications(
                data.notifications
            );

        } catch (err) {

            console.error(err);

        } finally {

            setLoading(false);

        }

    };

    useEffect(() => {

        loadNotifications();

    }, []);

    const handleRead = async (
        id: string
    ) => {

        try {

            await markAsRead(id);

            loadNotifications();

        } catch (err) {

            console.error(err);

        }

    };

    const handleDelete = async (
        id: string
    ) => {

        try {

            await deleteNotification(id);

            loadNotifications();

        } catch (err) {

            console.error(err);

        }

    };

    const handleReadAll = async () => {

        try {

            await markAllAsRead();

            loadNotifications();

        } catch (err) {

            console.error(err);

        }

    };

    if (loading) {

        return (

            <div className="flex h-80 items-center justify-center">

                Loading Notifications...

            </div>

        );

    }

    return (

        <div className="space-y-8">

            <div className="flex items-center justify-between">

                <div>

                    <h1 className="text-3xl font-bold">

                        Notifications

                    </h1>

                    <p className="mt-2 text-gray-500">

                        Stay updated with recent activity.

                    </p>

                </div>

                <button
                    onClick={handleReadAll}
                    className="rounded-xl bg-black px-5 py-2 text-white"
                >

                    Mark All Read

                </button>

            </div>

            {notifications.length === 0 && (

                <div className="rounded-3xl border border-dashed py-20 text-center">

                    <Bell
                        size={50}
                        className="mx-auto mb-4 text-gray-400"
                    />

                    <h2 className="text-2xl font-semibold">

                        No Notifications

                    </h2>

                </div>

            )}

            <div className="space-y-4">

                {notifications.map(
                    (notification) => (

                        <div
                            key={notification._id}
                            className={`rounded-2xl border p-5 ${notification.isRead
                                    ? "bg-white"
                                    : "bg-blue-50"
                                }`}
                        >

                            <div className="flex items-start justify-between">

                                <div>

                                    <h3 className="font-semibold">

                                        {notification.title}

                                    </h3>

                                    <p className="mt-2 text-gray-600">

                                        {
                                            notification.message
                                        }

                                    </p>

                                    <p className="mt-3 text-sm text-gray-400">

                                        {new Date(
                                            notification.createdAt
                                        ).toLocaleString()}

                                    </p>

                                </div>

                                <div className="flex gap-2">

                                    {!notification.isRead && (

                                        <button
                                            onClick={() =>
                                                handleRead(
                                                    notification._id
                                                )
                                            }
                                            className="rounded-lg bg-green-100 p-2 text-green-700"
                                        >

                                            <Check
                                                size={18}
                                            />

                                        </button>

                                    )}

                                    <button
                                        onClick={() =>
                                            handleDelete(
                                                notification._id
                                            )
                                        }
                                        className="rounded-lg bg-red-100 p-2 text-red-600"
                                    >

                                        <Trash2
                                            size={18}
                                        />

                                    </button>

                                </div>

                            </div>

                        </div>

                    )
                )}

            </div>

        </div>

    );

};

export default NotificationList;