import React, { useEffect, useState } from "react";
import { createAIInterviewSession } from "../../services/aiInterviewAgent.service";
import { getMyJobs } from "../../services/job.service";
import { getJobApplications } from "../../services/recruiter.service";
import type { Job } from "../../types/job";
import { Sparkles, X, User, Briefcase, Clock, ShieldAlert, Code2, Check, Sliders } from "lucide-react";
import toast from "react-hot-toast";

interface ScheduleAIInterviewModalProps {
    isOpen: boolean;
    onClose: () => void;
    applicationId?: string;
    candidateName?: string;
    jobTitle?: string;
    onSuccess?: () => void;
}

export const ScheduleAIInterviewModal: React.FC<ScheduleAIInterviewModalProps> = ({
    isOpen,
    onClose,
    applicationId: initialApplicationId,
    candidateName: initialCandidateName,
    jobTitle: initialJobTitle,
    onSuccess,
}) => {
    const [jobs, setJobs] = useState<Job[]>([]);
    const [selectedJobId, setSelectedJobId] = useState<string>("");
    const [applications, setApplications] = useState<any[]>([]);
    const [selectedApplicationId, setSelectedApplicationId] = useState<string>(initialApplicationId || "");
    const [loadingData, setLoadingData] = useState<boolean>(false);

    const [type, setType] = useState<any>("Mixed");
    const [duration, setDuration] = useState(45);
    const [difficulty, setDifficulty] = useState<any>("Adaptive");
    const [questionCount, setQuestionCount] = useState(6);
    const [codingEnabled, setCodingEnabled] = useState(true);
    const [systemDesignEnabled, setSystemDesignEnabled] = useState(false);
    const [submitting, setSubmitting] = useState(false);

    // Fetch recruiter jobs if opening without initial application
    useEffect(() => {
        if (isOpen && !initialApplicationId) {
            setLoadingData(true);
            getMyJobs()
                .then((data) => setJobs(data || []))
                .catch((err) => console.error("Error loading jobs:", err))
                .finally(() => setLoadingData(false));
        }
    }, [isOpen, initialApplicationId]);

    // Fetch applications when a job is selected
    useEffect(() => {
        if (selectedJobId && !initialApplicationId) {
            getJobApplications(selectedJobId)
                .then((data) => setApplications(data || []))
                .catch((err) => console.error("Error loading candidates:", err));
        }
    }, [selectedJobId, initialApplicationId]);

    if (!isOpen) return null;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        const targetAppId = initialApplicationId || selectedApplicationId;
        if (!targetAppId) {
            toast.error("Please select a candidate application to schedule.");
            return;
        }

        setSubmitting(true);
        try {
            await createAIInterviewSession({
                applicationId: targetAppId,
                type,
                config: {
                    duration,
                    difficulty,
                    questionCount,
                    codingEnabled,
                    systemDesignEnabled,
                },
            });
            toast.success("AI Interview session scheduled successfully!");
            if (onSuccess) onSuccess();
            onClose();
        } catch (err: any) {
            toast.error(err.response?.data?.message || "Failed to schedule AI Interview");
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
            <div className="w-full max-w-xl rounded-3xl bg-slate-900/90 border border-slate-800 p-7 shadow-2xl space-y-6 text-slate-100 backdrop-saturate-150">
                {/* Header */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-800/80">
                    <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
                            <Sparkles className="h-5 w-5" />
                        </div>
                        <div>
                            <h2 className="text-lg font-bold tracking-tight text-white">Schedule AI Interview Agent</h2>
                            <p className="text-xs text-slate-400">Autonomous, resume-grounded AI interviewer session</p>
                        </div>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition"
                    >
                        <X className="h-5 w-5" />
                    </button>
                </div>

                {/* Candidate & Job Context Selector */}
                {initialApplicationId ? (
                    <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 text-xs space-y-2">
                        <div className="flex items-center gap-2 text-slate-300">
                            <User className="h-4 w-4 text-blue-400 shrink-0" />
                            <span>Candidate: <strong className="text-white font-semibold">{initialCandidateName}</strong></span>
                        </div>
                        <div className="flex items-center gap-2 text-slate-300">
                            <Briefcase className="h-4 w-4 text-emerald-400 shrink-0" />
                            <span>Position: <strong className="text-white font-semibold">{initialJobTitle}</strong></span>
                        </div>
                    </div>
                ) : (
                    <div className="space-y-3 text-xs">
                        <div>
                            <label className="block text-slate-400 mb-1.5 font-semibold">1. Select Job Posting</label>
                            <select
                                value={selectedJobId}
                                onChange={(e) => {
                                    setSelectedJobId(e.target.value);
                                    setSelectedApplicationId("");
                                }}
                                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-slate-200 font-medium outline-none focus:border-blue-500 transition"
                            >
                                <option value="">-- Choose Job --</option>
                                {jobs.map((job) => (
                                    <option key={job._id} value={job._id}>
                                        {job.title} ({job.company || "Your Company"})
                                    </option>
                                ))}
                            </select>
                        </div>

                        {selectedJobId && (
                            <div>
                                <label className="block text-slate-400 mb-1.5 font-semibold">2. Select Applicant</label>
                                <select
                                    value={selectedApplicationId}
                                    onChange={(e) => setSelectedApplicationId(e.target.value)}
                                    className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-slate-200 font-medium outline-none focus:border-blue-500 transition"
                                >
                                    <option value="">-- Choose Candidate --</option>
                                    {applications.map((app) => (
                                        <option key={app._id} value={app._id}>
                                            {app.candidate?.name || "Applicant"} ({app.candidate?.email})
                                        </option>
                                    ))}
                                </select>
                            </div>
                        )}
                    </div>
                )}

                {/* Configuration Form */}
                <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                    <div>
                        <label className="block text-slate-400 mb-1.5 font-semibold flex items-center gap-1.5">
                            <Sliders className="h-3.5 w-3.5 text-blue-400" /> Interview Format
                        </label>
                        <select
                            value={type}
                            onChange={(e) => setType(e.target.value)}
                            className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-slate-200 font-medium outline-none focus:border-blue-500 transition"
                        >
                            <option value="Mixed">Mixed (Technical + Behavioral + Coding)</option>
                            <option value="Technical">Technical Deep Dive</option>
                            <option value="Behavioral">Behavioral & Leadership</option>
                            <option value="Coding">Coding & Algorithm Round</option>
                            <option value="SystemDesign">System Architecture & Design</option>
                            <option value="ResumeDeepDive">Resume & Project Deep Dive</option>
                        </select>
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                        <div>
                            <label className="block text-slate-400 mb-1.5 font-semibold">Duration (Min)</label>
                            <input
                                type="number"
                                value={duration}
                                onChange={(e) => setDuration(Number(e.target.value))}
                                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-slate-200 font-medium outline-none focus:border-blue-500 transition"
                                min={15}
                                max={90}
                            />
                        </div>

                        <div>
                            <label className="block text-slate-400 mb-1.5 font-semibold">Difficulty</label>
                            <select
                                value={difficulty}
                                onChange={(e) => setDifficulty(e.target.value)}
                                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-slate-200 font-medium outline-none focus:border-blue-500 transition"
                            >
                                <option value="Adaptive">Adaptive AI (Recommended)</option>
                                <option value="Easy">Easy</option>
                                <option value="Medium">Medium</option>
                                <option value="Hard">Hard</option>
                            </select>
                        </div>

                        <div>
                            <label className="block text-slate-400 mb-1.5 font-semibold">Max Questions</label>
                            <input
                                type="number"
                                value={questionCount}
                                onChange={(e) => setQuestionCount(Number(e.target.value))}
                                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-slate-200 font-medium outline-none focus:border-blue-500 transition"
                                min={3}
                                max={12}
                            />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-1">
                        <label
                            onClick={() => setCodingEnabled(!codingEnabled)}
                            className={`flex items-center gap-3 p-3.5 rounded-2xl border cursor-pointer transition ${codingEnabled
                                ? "bg-blue-950/40 border-blue-500/50 text-blue-300"
                                : "bg-slate-950/60 border-slate-800 text-slate-400"
                                }`}
                        >
                            <div className={`h-4 w-4 rounded flex items-center justify-center border ${codingEnabled ? "bg-blue-600 border-blue-500 text-white" : "border-slate-700"
                                }`}>
                                {codingEnabled && <Check className="h-3 w-3 stroke-[3]" />}
                            </div>
                            <span className="font-semibold text-[11px]">Interactive Coding Round</span>
                        </label>

                        <label
                            onClick={() => setSystemDesignEnabled(!systemDesignEnabled)}
                            className={`flex items-center gap-3 p-3.5 rounded-2xl border cursor-pointer transition ${systemDesignEnabled
                                ? "bg-purple-950/40 border-purple-500/50 text-purple-300"
                                : "bg-slate-950/60 border-slate-800 text-slate-400"
                                }`}
                        >
                            <div className={`h-4 w-4 rounded flex items-center justify-center border ${systemDesignEnabled ? "bg-purple-600 border-purple-500 text-white" : "border-slate-700"
                                }`}>
                                {systemDesignEnabled && <Check className="h-3 w-3 stroke-[3]" />}
                            </div>
                            <span className="font-semibold text-[11px]">System Design Round</span>
                        </label>
                    </div>

                    <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-800/80">
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold transition"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            disabled={submitting}
                            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold shadow-lg shadow-blue-500/20 transition flex items-center gap-2"
                        >
                            {submitting ? (
                                <>
                                    <Sparkles className="h-4 w-4 animate-spin" />
                                    <span>Scheduling...</span>
                                </>
                            ) : (
                                <>
                                    <Sparkles className="h-4 w-4" />
                                    <span>Schedule AI Interview</span>
                                </>
                            )}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};
