import { Outlet } from "react-router-dom";

import CandidateSidebar from "../components/candidate/CandidateSidebar";
import Topbar from "../components/dashboard/Topbar";

const CandidateLayout = () => {
    return (
        <div className="flex min-h-screen bg-[#fafafa]">

            <CandidateSidebar />

            <div className="flex flex-1 flex-col">

                <Topbar />

                <main className="flex-1 overflow-y-auto p-8">
                    <Outlet />
                </main>

            </div>

        </div>
    );
};

export default CandidateLayout;