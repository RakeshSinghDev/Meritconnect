import Container from "../../common/Container";

const companies = [
    "Google",
    "Microsoft",
    "OpenAI",
    "Amazon",
    "Netflix",
    "Adobe",
];

export default function Companies() {
    return (
        <section className="border-y border-gray-200 bg-gray-50 py-16">
            <Container>
                <div className="text-center">
                    <p className="text-sm font-medium uppercase tracking-[0.25em] text-gray-500">
                        Trusted by innovative companies
                    </p>

                    <div className="mt-10 grid grid-cols-2 gap-8 md:grid-cols-3 lg:grid-cols-6">
                        {companies.map((company) => (
                            <div
                                key={company}
                                className="flex h-16 items-center justify-center rounded-xl border border-gray-200 bg-white text-lg font-semibold text-gray-700 transition-all duration-300 hover:border-gray-900 hover:text-black"
                            >
                                {company}
                            </div>
                        ))}
                    </div>
                </div>
            </Container>
        </section>
    );
}