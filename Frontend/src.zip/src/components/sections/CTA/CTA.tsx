import { ArrowRight } from "lucide-react";

import Container from "../../common/Container";
import Button from "../../ui/Button";

export default function CTA() {
    return (
        <section className="py-32">
            <Container>
                <div className="overflow-hidden rounded-[40px] bg-black px-8 py-20 text-center text-white md:px-16">
                    <p className="text-sm font-semibold uppercase tracking-[0.3em] text-gray-400">
                        Get Started
                    </p>

                    <h2 className="mx-auto mt-6 max-w-4xl text-4xl font-semibold tracking-tight md:text-6xl">
                        Build the future of hiring with AI.
                    </h2>

                    <p className="mx-auto mt-8 max-w-2xl text-lg leading-8 text-gray-300">
                        Analyze resumes, conduct AI interviews, and hire exceptional
                        candidates faster with one intelligent recruitment platform.
                    </p>

                    <div className="mt-12 flex justify-center">
                        <Button
                            size="lg"
                            className="bg-white text-black hover:bg-gray-100"
                        >
                            Get Started

                            <ArrowRight className="ml-2 h-5 w-5" />
                        </Button>
                    </div>
                </div>
            </Container>
        </section>
    );
}