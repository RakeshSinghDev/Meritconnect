import Container from "../../common/Container";
import Button from "../../ui/Button";

export default function Hero() {
    return (
        <section className="relative overflow-hidden border-b border-gray-200 bg-white pt-40 pb-32">
            <Container>
                <div className="mx-auto max-w-5xl text-center">
                    {/* Heading */}
                    <h1 className="text-5xl font-semibold tracking-tight text-gray-900 md:text-7xl lg:text-8xl">
                        Hire Smarter.
                        <br />
                        Recruit Faster.
                    </h1>

                    {/* Description */}
                    <p className="mx-auto mt-8 max-w-3xl text-lg leading-8 text-gray-600 md:text-xl">
                        MeritConnect helps recruiters discover top talent with AI-powered
                        resume analysis, intelligent candidate matching, adaptive AI
                        interviews, and streamlined hiring workflows.
                    </p>

                    {/* CTA Buttons */}
                    <div className="mt-12 flex flex-col items-center justify-center gap-4 sm:flex-row">
                        <Button size="lg">
                            Get Started
                        </Button>

                        <Button variant="ghost" size="lg">
                            Explore Platform
                        </Button>
                    </div>
                </div>
            </Container>
        </section>
    );
}