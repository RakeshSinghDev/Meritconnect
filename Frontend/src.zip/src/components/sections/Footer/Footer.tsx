import {
    FaGithub,
    FaLinkedin,
    FaXTwitter,
} from "react-icons/fa6";
import { Link } from "react-router-dom";

import Container from "../../common/Container";

export default function Footer() {
    const productLinks = [
        "Features",
        "AI Workflow",
        "Dashboard",
        "Security",
    ];

    const companyLinks = [
        "About",
        "Contact",
        "Careers",
    ];

    const resourceLinks = [
        "FAQ",
        "Privacy Policy",
        "Terms of Service",
    ];

    return (
        <footer className="border-t border-gray-200 bg-white">
            <Container>
                <div className="grid gap-16 py-20 lg:grid-cols-5">

                    {/* Brand */}

                    <div className="lg:col-span-2">

                        <Link
                            to="/"
                            className="text-3xl font-bold tracking-tight text-gray-900"
                        >
                            MeritConnect
                        </Link>

                        <p className="mt-6 max-w-md leading-7 text-gray-600">
                            AI-powered recruitment platform helping recruiters discover,
                            evaluate, and hire exceptional talent with confidence.
                        </p>

                        <div className="mt-8 flex gap-4">

                            <a
                                href="#"
                                className="rounded-xl border border-gray-200 p-3 transition hover:bg-gray-100"
                            >
                                <FaGithub size={20} />
                            </a>

                            <a
                                href="#"
                                className="rounded-xl border border-gray-200 p-3 transition hover:bg-gray-100"
                            >
                                <FaLinkedin size={20} />
                            </a>

                            <a
                                href="#"
                                className="rounded-xl border border-gray-200 p-3 transition hover:bg-gray-100"
                            >
                                <FaXTwitter size={20} />
                            </a>

                        </div>
                    </div>

                    {/* Product */}

                    <div>

                        <h3 className="font-semibold text-gray-900">
                            Product
                        </h3>

                        <div className="mt-5 space-y-4">
                            {productLinks.map((item) => (
                                <a
                                    key={item}
                                    href="#"
                                    className="block text-gray-600 transition hover:text-black"
                                >
                                    {item}
                                </a>
                            ))}
                        </div>

                    </div>

                    {/* Company */}

                    <div>

                        <h3 className="font-semibold text-gray-900">
                            Company
                        </h3>

                        <div className="mt-5 space-y-4">
                            {companyLinks.map((item) => (
                                <a
                                    key={item}
                                    href="#"
                                    className="block text-gray-600 transition hover:text-black"
                                >
                                    {item}
                                </a>
                            ))}
                        </div>

                    </div>

                    {/* Resources */}

                    <div>

                        <h3 className="font-semibold text-gray-900">
                            Resources
                        </h3>

                        <div className="mt-5 space-y-4">
                            {resourceLinks.map((item) => (
                                <a
                                    key={item}
                                    href="#"
                                    className="block text-gray-600 transition hover:text-black"
                                >
                                    {item}
                                </a>
                            ))}
                        </div>

                    </div>

                </div>

                <div className="flex flex-col items-center justify-between gap-4 border-t border-gray-200 py-8 text-sm text-gray-500 md:flex-row">
                    <p>© {new Date().getFullYear()} MeritConnect. All rights reserved.</p>

                    <p>Built for modern AI-powered recruitment.</p>
                </div>
            </Container>
        </footer>
    );
}