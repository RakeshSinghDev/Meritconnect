interface WorkflowCardProps {
    step: string;
    title: string;
    description: string;
}

export default function WorkflowCard({
    step,
    title,
    description,
}: WorkflowCardProps) {
    return (
        <div className="relative rounded-3xl border border-gray-200 bg-white p-8">
            <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-full bg-black text-lg font-semibold text-white">
                {step}
            </div>

            <h3 className="text-2xl font-semibold text-gray-900">
                {title}
            </h3>

            <p className="mt-4 leading-7 text-gray-600">
                {description}
            </p>
        </div>
    );
}