import { useState } from "react";
import { ChevronDown } from "lucide-react";

interface FAQItemProps {
    question: string;
    answer: string;
}

export default function FAQItem({
    question,
    answer,
}: FAQItemProps) {
    const [open, setOpen] = useState(false);

    return (
        <div className="rounded-3xl border border-gray-200 bg-white transition-all">
            <button
                onClick={() => setOpen(!open)}
                className="flex w-full items-center justify-between p-6 text-left"
            >
                <h3 className="text-lg font-semibold text-gray-900">
                    {question}
                </h3>

                <ChevronDown
                    className={`h-5 w-5 transition-transform ${open ? "rotate-180" : ""
                        }`}
                />
            </button>

            {open && (
                <div className="px-6 pb-6">
                    <p className="leading-7 text-gray-600">
                        {answer}
                    </p>
                </div>
            )}
        </div>
    );
}