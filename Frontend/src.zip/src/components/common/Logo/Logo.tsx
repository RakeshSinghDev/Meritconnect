export default function Logo() {
    return (
        <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-black text-white font-bold">
                M
            </div>

            <span className="text-xl font-semibold tracking-tight">
                MeritConnect
            </span>
        </div>
    );
}