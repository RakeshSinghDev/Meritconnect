import Button from "../ui/Button";

const JobForm = () => {
    return (
        <form className="space-y-6">

            <div>
                <label className="mb-2 block text-sm font-medium">
                    Job Title
                </label>

                <input
                    className="w-full rounded-xl border border-gray-200 p-3 focus:border-black outline-none"
                    placeholder="Frontend Developer"
                />
            </div>

            <div>
                <label className="mb-2 block text-sm font-medium">
                    Company
                </label>

                <input
                    className="w-full rounded-xl border border-gray-200 p-3 focus:border-black outline-none"
                    placeholder="MeritConnect"
                />
            </div>

            <div className="grid grid-cols-2 gap-5">

                <div>

                    <label className="mb-2 block text-sm font-medium">
                        Location
                    </label>

                    <input
                        className="w-full rounded-xl border border-gray-200 p-3 focus:border-black outline-none"
                        placeholder="Remote"
                    />

                </div>

                <div>

                    <label className="mb-2 block text-sm font-medium">
                        Employment
                    </label>

                    <select
                        className="w-full rounded-xl border border-gray-200 p-3"
                    >
                        <option>Full Time</option>
                        <option>Internship</option>
                        <option>Contract</option>
                    </select>

                </div>

            </div>

            <div>

                <label className="mb-2 block text-sm font-medium">
                    Description
                </label>

                <textarea
                    rows={6}
                    className="w-full rounded-xl border border-gray-200 p-3 outline-none focus:border-black"
                />

            </div>

            <div className="flex justify-end gap-3">

                <button
                    type="button"
                    className="rounded-xl border border-gray-200 px-6 py-3 hover:bg-gray-100"
                >
                    Cancel
                </button>

                <Button>
                    Create Job
                </Button>

            </div>

        </form>
    );
};

export default JobForm;