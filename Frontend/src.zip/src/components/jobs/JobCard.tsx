import { MapPin, Clock } from "lucide-react";
import JobStatusBadge from "./JobStatusBadge";

const JobCard = () => {
    return (

        <div className="rounded-3xl border border-gray-200 bg-white p-6 shadow-sm">

            <div className="flex items-center justify-between">

                <div>

                    <h2 className="text-xl font-semibold">
                        Frontend Developer
                    </h2>

                    <p className="mt-2 text-gray-500">
                        MeritConnect
                    </p>

                </div>

                <JobStatusBadge status="Active" />

            </div>

            <div className="mt-6 flex gap-6 text-sm text-gray-500">

                <span className="flex items-center gap-2">
                    <MapPin size={16} />
                    Remote
                </span>

                <span className="flex items-center gap-2">
                    <Clock size={16} />
                    Full Time
                </span>

            </div>

            <div className="mt-8 flex gap-3">

                <button className="rounded-xl border border-gray-200 px-5 py-2 hover:bg-gray-100">
                    View
                </button>

                <button className="rounded-xl border border-gray-200 px-5 py-2 hover:bg-gray-100">
                    Edit
                </button>

                <button className="rounded-xl bg-red-500 px-5 py-2 text-white hover:bg-red-600">
                    Delete
                </button>

            </div>

        </div>

    );
};

export default JobCard;