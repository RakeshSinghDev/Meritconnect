import {
    Bell,
    ChevronDown,
    Menu,
    Search,
} from "lucide-react";

const Topbar = () => {
    return (
        <header className="sticky top-0 z-40 flex h-20 items-center justify-between border-b border-gray-200 bg-white px-8">

            {/* Left */}
            <div className="flex items-center gap-4">

                {/* Mobile Sidebar Button */}
                <button className="rounded-lg border border-gray-200 p-2 transition hover:bg-gray-100 lg:hidden">
                    <Menu size={20} />
                </button>

                {/* Search */}
                <div className="relative hidden md:block">
                    <Search
                        size={18}
                        className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"
                    />

                    <input
                        type="text"
                        placeholder="Search jobs, candidates or applications..."
                        className="h-11 w-[420px] rounded-xl border border-gray-200 bg-gray-50 pl-11 pr-20 text-sm outline-none transition focus:border-black focus:bg-white"
                    />

                    <span className="absolute right-4 top-1/2 -translate-y-1/2 rounded-md border border-gray-200 bg-white px-2 py-0.5 text-xs text-gray-500">
                        ⌘ K
                    </span>
                </div>

            </div>

            {/* Right */}
            <div className="flex items-center gap-5">

                {/* Notification */}
                <button className="relative rounded-xl border border-gray-200 p-2 transition hover:bg-gray-100">

                    <Bell size={20} />

                    <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-red-500"></span>

                </button>

                {/* Profile */}
                <button className="flex items-center gap-3 rounded-xl border border-gray-200 px-3 py-2 transition hover:bg-gray-50">

                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-black text-sm font-semibold text-white">
                        R
                    </div>

                    <div className="hidden text-left md:block">

                        <h3 className="text-sm font-semibold">
                            Rakesh Singh
                        </h3>

                        <p className="text-xs text-gray-500">
                            Recruiter
                        </p>

                    </div>

                    <ChevronDown size={18} />

                </button>

            </div>

        </header>
    );
};

export default Topbar;