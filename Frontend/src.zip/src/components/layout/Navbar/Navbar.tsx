import { Menu } from "lucide-react";
import Container from "../../common/Container/Container";
import Logo from "../../common/Logo/Logo";
import Button from "../../ui/Button";

export default function Navbar() {
    return (
        <header className="sticky top-0 z-50 border-b border-gray-200 bg-white/90 backdrop-blur-md">
            <Container>
                <div className="flex h-20 items-center justify-between">

                    {/* Logo */}
                    <Logo />

                    {/* Desktop Navigation */}
                    <nav className="hidden items-center gap-10 md:flex">
                        <a
                            href="#features"
                            className="text-sm font-medium text-gray-600 transition hover:text-black"
                        >
                            Features
                        </a>

                        <a
                            href="#companies"
                            className="text-sm font-medium text-gray-600 transition hover:text-black"
                        >
                            Companies
                        </a>

                        <a
                            href="#pricing"
                            className="text-sm font-medium text-gray-600 transition hover:text-black"
                        >
                            Pricing
                        </a>

                        <a
                            href="#contact"
                            className="text-sm font-medium text-gray-600 transition hover:text-black"
                        >
                            Contact
                        </a>
                    </nav>

                    {/* Right Side */}
                    <div className="hidden items-center gap-4 md:flex">
                        <Button variant="ghost">
                            Login
                        </Button>

                        <Button>
                            Get Started
                        </Button>
                    </div>

                    {/* Mobile Menu */}
                    <button className="md:hidden">
                        <Menu size={26} />
                    </button>

                </div>
            </Container>
        </header>
    );
}