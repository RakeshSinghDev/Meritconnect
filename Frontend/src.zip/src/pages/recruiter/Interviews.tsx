export default function Interviews() {
    return <h1 className="text-4xl font-bold">Interviews</h1>;
}