import DashboardHeader from "../../components/dashboard/DashboardHeader/DashboardHeader";
import QuickActions from "../../components/dashboard/QuickActions/QuickActions";
import SectionCard from "../../components/dashboard/SectionCard/SectionCard";
import EmptyState from "../../components/dashboard/EmptyState/EmptyState";

const Dashboard = () => {
    return (
        <>
            <DashboardHeader />

            <QuickActions />

            <div className="grid gap-6 lg:grid-cols-2">
                <SectionCard title="Recent Applications">
                    <EmptyState
                        title="No applications yet"
                        description="Applications will appear here after candidates apply."
                    />
                </SectionCard>

                <SectionCard title="AI Insights">
                    <EmptyState
                        title="No insights available"
                        description="AI recommendations will appear after you receive applications."
                    />
                </SectionCard>
            </div>

            <div className="mt-6">
                <SectionCard title="Hiring Pipeline">
                    <EmptyState
                        title="No hiring activity"
                        description="Create your first job to begin hiring."
                    />
                </SectionCard>
            </div>
        </>
    );
};

export default Dashboard;