import { useState } from "react";

import Button from "../../components/ui/Button";
import Drawer from "../../components/ui/Drawer";

import EmptyJobs from "../../components/jobs/EmptyJobs";
import JobFilters from "../../components/jobs/JobFilters";
import JobForm from "../../components/jobs/JobForm";

const Jobs = () => {

    const [open, setOpen] = useState(false);

    const hasJobs = false;

    return (
        <>

            <div className="mb-10 flex items-center justify-between">

                <div>

                    <h1 className="text-4xl font-bold">
                        Jobs
                    </h1>

                    <p className="mt-2 text-gray-500">
                        Manage all your job postings.
                    </p>

                </div>

                <button
                    onClick={() => {
                        console.log("clicked");
                        setOpen(true);
                    }}
                    className="rounded-lg bg-black px-4 py-2 text-white"
                >
                    Test Drawer
                </button>

            </div>

            <JobFilters />

            {hasJobs ? (
                <></>
            ) : (
                <EmptyJobs />
            )}
            <p className="mb-4 text-red-600">
                {open ? "Drawer Open" : "Drawer Closed"}
            </p>
            <Drawer
                open={open}
                title="Create New Job"
                onClose={() => setOpen(false)}
            >
                <JobForm />
            </Drawer>

        </>
    );
};

export default Jobs;