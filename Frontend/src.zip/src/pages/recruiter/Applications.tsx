export default function Applications() {
    return (
        <div>
            <h1 className="text-4xl font-bold">
                Recruiter Applications
            </h1>
        </div>
    );
}