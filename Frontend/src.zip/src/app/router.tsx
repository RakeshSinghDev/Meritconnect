import { createBrowserRouter } from "react-router-dom";

import HomePage from "../pages/HomePage";
import DashboardLayout from "../layouts/DashboardLayout";

import Dashboard from "../pages/recruiter/Dashboard";
import Jobs from "../pages/recruiter/Jobs";
import Applications from "../pages/recruiter/Applications";
import Candidates from "../pages/recruiter/Candidates";
import Interviews from "../pages/recruiter/Interviews";
import Analytics from "../pages/recruiter/Analytics";
import Settings from "../pages/recruiter/Settings";

export const router = createBrowserRouter([
    {
        path: "/",
        element: <HomePage />,
    },

    {
        path: "/recruiter",
        element: <DashboardLayout />,
        children: [
            {
                path: "dashboard",
                element: <Dashboard />,
            },
            {
                path: "jobs",
                element: <Jobs />,
            },
            {
                path: "applications",
                element: <Applications />,
            },
            {
                path: "candidates",
                element: <Candidates />,
            },
            {
                path: "interviews",
                element: <Interviews />,
            },
            {
                path: "analytics",
                element: <Analytics />,
            },
            {
                path: "settings",
                element: <Settings />,
            },
        ],
    },
]);