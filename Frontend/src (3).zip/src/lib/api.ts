import axios from "axios";

const api = axios.create({
    baseURL: import.meta.env.VITE_API_BASE_URL,
    withCredentials: true,
    headers: {
        "Content-Type": "application/json",
    },
});

// Remove Authorization header interceptor
api.interceptors.response.use(
    (response) => response,
    (error) => Promise.reject(error)
);

export default api;