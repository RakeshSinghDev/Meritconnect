import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { register } from "../../services/auth.service";

const Register = () => {
    const navigate = useNavigate();

    const [form, setForm] = useState({
        name: "",
        email: "",
        password: "",
        role: "candidate",
    });

    const [loading, setLoading] = useState(false);

    const [error, setError] = useState("");

    const handleChange = (
        e: React.ChangeEvent<
            HTMLInputElement | HTMLSelectElement
        >
    ) => {
        setForm((prev) => ({
            ...prev,
            [e.target.name]: e.target.value,
        }));
    };

    const handleSubmit = async (
        e: React.FormEvent
    ) => {
        e.preventDefault();

        try {
            setLoading(true);
            setError("");

            await register({
                name: form.name,
                email: form.email,
                password: form.password,
                role: form.role as
                    | "candidate"
                    | "recruiter",
            });

            navigate("/login");

        } catch (err: any) {

            setError(
                err?.response?.data?.message ??
                "Registration failed."
            );

        } finally {

            setLoading(false);

        }
    };

    return (
        <div className="flex min-h-screen items-center justify-center bg-gray-50">

            <div className="w-full max-w-lg rounded-3xl bg-white p-8 shadow-lg">

                <h1 className="mb-2 text-3xl font-bold">
                    Create Account
                </h1>

                <p className="mb-8 text-gray-500">
                    Join MeritConnect
                </p>

                <form
                    onSubmit={handleSubmit}
                    className="space-y-5"
                >

                    <input
                        type="text"
                        name="name"
                        placeholder="Full Name"
                        value={form.name}
                        onChange={handleChange}
                        className="w-full rounded-xl border p-3"
                        required
                    />

                    <input
                        type="email"
                        name="email"
                        placeholder="Email"
                        value={form.email}
                        onChange={handleChange}
                        className="w-full rounded-xl border p-3"
                        required
                    />

                    <input
                        type="password"
                        name="password"
                        placeholder="Password"
                        value={form.password}
                        onChange={handleChange}
                        className="w-full rounded-xl border p-3"
                        required
                    />

                    <select
                        name="role"
                        value={form.role}
                        onChange={handleChange}
                        className="w-full rounded-xl border p-3"
                    >
                        <option value="candidate">
                            Candidate
                        </option>

                        <option value="recruiter">
                            Recruiter
                        </option>
                    </select>

                    {error && (
                        <p className="text-sm text-red-500">
                            {error}
                        </p>
                    )}

                    <button
                        disabled={loading}
                        className="w-full rounded-xl bg-black py-3 text-white"
                    >
                        {loading
                            ? "Creating Account..."
                            : "Register"}
                    </button>

                </form>

                <p className="mt-6 text-center text-sm text-gray-500">
                    Already have an account?{" "}
                    <Link
                        to="/login"
                        className="font-semibold text-black"
                    >
                        Login
                    </Link>
                </p>

            </div>

        </div>
    );
};

export default Register;