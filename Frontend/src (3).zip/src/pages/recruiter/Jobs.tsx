import { useEffect, useState } from "react";

import Drawer from "../../components/ui/Drawer";

import EmptyJobs from "../../components/jobs/EmptyJobs";
import JobFilters from "../../components/jobs/JobFilters";
import JobForm from "../../components/jobs/JobForm";
import JobCard from "../../components/jobs/JobCard";

import {
    getMyJobs,
    createJob,
    updateJob,
    deleteJob,
} from "../../services/job.service";

import type {
    Job,
    CreateJobDto,
    UpdateJobDto,
} from "../../types/job";

const Jobs = () => {
    const [jobs, setJobs] = useState<Job[]>([]);
    const [loading, setLoading] = useState(true);

    const [open, setOpen] = useState(false);

    const [editingJob, setEditingJob] =
        useState<Job | null>(null);

    const loadJobs = async () => {
        try {
            setLoading(true);

            const data = await getMyJobs();

            setJobs(data);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadJobs();
    }, []);

    const handleCreate = async (
        form: CreateJobDto
    ) => {
        try {
            await createJob(form);

            setOpen(false);

            await loadJobs();
        } catch (error) {
            console.error(error);
        }
    };

    const handleUpdate = async (
        form: UpdateJobDto
    ) => {
        if (!editingJob) return;

        try {
            await updateJob(
                editingJob.id,
                form
            );

            setEditingJob(null);

            setOpen(false);

            await loadJobs();
        } catch (error) {
            console.error(error);
        }
    };

    const handleDelete = async (
        id: string
    ) => {
        try {
            await deleteJob(id);

            await loadJobs();
        } catch (error) {
            console.error(error);
        }
    };

    const hasJobs = jobs.length > 0;

    return (
        <>
            <div className="mb-10 flex items-center justify-between">
                <div>
                    <h1 className="text-4xl font-bold">
                        Jobs
                    </h1>

                    <p className="mt-2 text-gray-500">
                        Manage all your job postings.
                    </p>
                </div>

                <button
                    onClick={() => {
                        setEditingJob(null);
                        setOpen(true);
                    }}
                    className="rounded-lg bg-black px-4 py-2 text-white"
                >
                    Create Job
                </button>
            </div>

            <JobFilters />

            {loading ? (
                <p className="text-center py-10 text-gray-500">
                    Loading jobs...
                </p>
            ) : hasJobs ? (
                <div className="grid gap-6">
                    {jobs.map((job) => (
                        <JobCard
                            key={job.id}
                            job={job}
                            onEdit={(job) => {
                                setEditingJob(job);
                                setOpen(true);
                            }}
                            onDelete={handleDelete}
                        />
                    ))}
                </div>
            ) : (
                <EmptyJobs
                    onCreateJob={() => {
                        setEditingJob(null);
                        setOpen(true);
                    }}
                />
            )}

            <Drawer
                open={open}
                title={
                    editingJob
                        ? "Edit Job"
                        : "Create New Job"
                }
                onClose={() => {
                    setEditingJob(null);
                    setOpen(false);
                }}
            >
                <JobForm
                    initialData={editingJob}
                    onCancel={() => {
                        setEditingJob(null);
                        setOpen(false);
                    }}
                    onSubmit={(form) => {
                        if (editingJob) {
                            handleUpdate(form);
                        } else {
                            handleCreate(form);
                        }
                    }}
                />
            </Drawer>
        </>
    );
};

export default Jobs;