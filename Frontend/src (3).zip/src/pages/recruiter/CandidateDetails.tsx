import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
    ArrowLeft,
    Download,
    Mail,
    Phone,
    User,
    FileText,
    Loader2,
} from "lucide-react";

import AIResumeScore from "../../components/ai/AIResumeScore";
import ATSScore from "../../components/ai/ATSScore";
import SkillMatch from "../../components/ai/SkillMatch";
import MissingSkills from "../../components/ai/MissingSkills";
import RecommendationCard from "../../components/ai/RecommendationCard";
import AISummary from "../../components/ai/AISummary";

import {
    analyzeResume,
    shortlistCandidate,
    rejectCandidate,
} from "../../services/ai.service";

import type { ResumeAnalysis } from "../../types/ai";

const CandidateDetails = () => {

    const { applicationId } = useParams();

    const navigate = useNavigate();

    const [loading, setLoading] = useState(true);

    const [actionLoading, setActionLoading] = useState(false);

    const [error, setError] = useState("");

    const [analysis, setAnalysis] =
        useState<ResumeAnalysis | null>(null);

    useEffect(() => {
        loadCandidate();
    }, [applicationId]);
    const loadCandidate = async () => {

        try {

            setLoading(true);

            const response = await analyzeResume(
                applicationId as string
            );

            setAnalysis(response);

        } catch (err) {

            console.error(err);

            setError("Unable to load candidate.");

        } finally {

            setLoading(false);

        }

    };
    const handleShortlist = async () => {

        try {

            setActionLoading(true);

            await shortlistCandidate(applicationId as string);

            alert("Candidate shortlisted.");

        } catch (err) {

            console.error(err);

            alert("Unable to shortlist.");

        } finally {

            setActionLoading(false);

        }

    };
    const handleReject = async () => {

        try {

            setActionLoading(true);

            await rejectCandidate(applicationId as string);

            alert("Candidate rejected.");

        } catch (err) {

            console.error(err);

            alert("Unable to reject.");

        } finally {

            setActionLoading(false);

        }

    };
    if (loading) {
        return (
            <div className="flex h-[70vh] items-center justify-center">

                <Loader2
                    className="animate-spin text-indigo-600"
                    size={40}
                />

            </div>
        );
    }
    if (error) {

        return (

            <div className="rounded-xl border border-red-200 bg-red-50 p-8">

                <h2 className="text-xl font-semibold text-red-600">
                    {error}
                </h2>

            </div>

        );

    }

    if (!analysis) return null;
    return (

        <div className="space-y-8">

            <button
                onClick={() => navigate(-1)}
                className="flex items-center gap-2 text-sm font-medium text-indigo-600 hover:text-indigo-700"
            >
                <ArrowLeft size={18} />

                Back
            </button>
            <div className="rounded-3xl border border-gray-200 bg-white p-8 shadow-sm">

                <div className="flex flex-col justify-between gap-8 lg:flex-row">

                    <div className="flex gap-6">

                        <div className="flex h-24 w-24 items-center justify-center rounded-full bg-indigo-100">

                            <User
                                size={40}
                                className="text-indigo-600"
                            />

                        </div>

                        <div>

                            <h1 className="text-3xl font-bold text-gray-900">
                                John Doe
                            </h1>

                            <p className="mt-2 text-gray-500">
                                Frontend Developer
                            </p>

                            <div className="mt-5 flex flex-wrap gap-6">

                                <div className="flex items-center gap-2">

                                    <Mail
                                        size={18}
                                        className="text-gray-400"
                                    />

                                    <span>
                                        john@gmail.com
                                    </span>

                                </div>

                                <div className="flex items-center gap-2">

                                    <Phone
                                        size={18}
                                        className="text-gray-400"
                                    />

                                    <span>
                                        +91 9876543210
                                    </span>

                                </div>

                            </div>
                        </div>

                    </div>
                    <div className="flex gap-3">

                        <button
                            className="flex items-center gap-2 rounded-xl border border-gray-200 px-5 py-3 hover:bg-gray-50"
                        >
                            <FileText size={18} />

                            Resume
                        </button>

                        <button
                            className="flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-white hover:bg-indigo-700"
                        >
                            <Download size={18} />

                            Download
                        </button>

                    </div>

                </div>

            </div>
            <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">

                {/* Left Column */}
                <div className="space-y-6">

                    <AIResumeScore
                        score={analysis.overallScore}
                    />

                    <ATSScore
                        score={analysis.atsScore}
                    />

                    <RecommendationCard
                        recommendation={analysis.recommendation}
                        confidence={analysis.overallScore}
                    />

                </div>

                {/* Right Column */}
                <div className="space-y-6">

                    <SkillMatch
                        skills={analysis.matchedSkills}
                    />

                    <MissingSkills
                        skills={analysis.missingSkills}
                    />

                </div>

            </div>

            {/* AI Summary */}

            <AISummary
                summary={analysis.summary}
                strengths={analysis.strengths}
                improvements={analysis.missingSkills}
            />

            {/* Experience & Education */}

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">

                {/* Experience */}

                <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">

                    <h2 className="mb-6 text-xl font-semibold text-gray-900">
                        Experience Match
                    </h2>

                    <div className="space-y-5">

                        <div className="flex items-center justify-between">

                            <span className="text-gray-500">
                                Candidate Experience
                            </span>

                            <span className="text-lg font-semibold">
                                {analysis.experience.candidate} Years
                            </span>

                        </div>

                        <div className="flex items-center justify-between">

                            <span className="text-gray-500">
                                Required Experience
                            </span>

                            <span className="text-lg font-semibold">
                                {analysis.experience.required} Years
                            </span>

                        </div>

                    </div>

                </div>

                {/* Education */}

                <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">

                    <h2 className="mb-6 text-xl font-semibold text-gray-900">
                        Education
                    </h2>

                    <div className="rounded-xl bg-gray-50 p-5">

                        <p className="text-lg font-semibold text-gray-900">
                            {analysis.education}
                        </p>

                    </div>

                </div>

            </div>

            {/* Projects */}

            <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">

                <div className="flex items-center justify-between">

                    <h2 className="text-xl font-semibold text-gray-900">
                        Projects Score
                    </h2>

                    <span className="text-3xl font-bold text-indigo-600">
                        {analysis.projectsScore}/5
                    </span>

                </div>

                <div className="mt-6 h-3 overflow-hidden rounded-full bg-gray-200">

                    <div
                        className="h-full rounded-full bg-indigo-600 transition-all duration-500"
                        style={{
                            width: `${analysis.projectsScore * 20}%`,
                        }}
                    />

                </div>

                <div className="mt-3 flex justify-between text-sm text-gray-500">

                    <span>Poor</span>

                    <span>Excellent</span>

                </div>

            </div>
            {/* Recruiter Actions */}

            <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">

                <h2 className="mb-6 text-xl font-semibold text-gray-900">
                    Recruiter Actions
                </h2>

                <div className="flex flex-wrap gap-4">
                    <button
                        onClick={() =>
                            navigate(
                                `/recruiter/candidates/${applicationId}`
                            )
                        }
                        className="rounded-lg bg-indigo-50 px-3 py-2 text-sm font-medium text-indigo-600 hover:bg-indigo-100"
                    >
                        Resume Match
                    </button>
                    {/* Shortlist */}

                    <button
                        onClick={handleShortlist}
                        disabled={actionLoading}
                        className="rounded-xl bg-emerald-600 px-6 py-3 font-medium text-white transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                        {actionLoading
                            ? "Processing..."
                            : "Shortlist Candidate"}
                    </button>

                    {/* Schedule Interview */}

                    <button
                        onClick={() =>
                            navigate(
                                `/recruiter/interviews/create/${applicationId}`
                            )
                        }
                        className="rounded-xl bg-indigo-600 px-6 py-3 font-medium text-white transition hover:bg-indigo-700"
                    >
                        Schedule Interview
                    </button>

                    {/* Reject */}

                    <button
                        onClick={handleReject}
                        disabled={actionLoading}
                        className="rounded-xl border border-red-200 bg-red-50 px-6 py-3 font-medium text-red-600 transition hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                        Reject Candidate
                    </button>

                </div>

            </div>

        </div>
    );
};

export default CandidateDetails;