import {
    createContext,
    useContext,
    useEffect,
    useState,
} from "react";

import {
    login,
    logout,
    me,
} from "../services/auth.service";

interface User {
    _id: string;
    name: string;
    email: string;
    role: "candidate" | "recruiter";
}

interface AuthContextType {
    user: User | null;
    loading: boolean;
    loginUser: (
        email: string,
        password: string
    ) => Promise<void>;
    logoutUser: () => Promise<void>;
}

const AuthContext =
    createContext<AuthContextType>(
        {} as AuthContextType
    );

export const AuthProvider = ({
    children,
}: {
    children: React.ReactNode;
}) => {

    const [user, setUser] =
        useState<User | null>(null);

    const [loading, setLoading] =
        useState(true);

    useEffect(() => {

        const loadUser = async () => {

            try {

                const data =
                    await me();

                setUser(data.user);

            } catch {

                setUser(null);

            } finally {

                setLoading(false);

            }

        };

        loadUser();

    }, []);

    const loginUser = async (
        email: string,
        password: string
    ) => {
        console.log("loginUser called", email);

        const data = await login({
            email,
            password,
        });

        console.log("API response:", data);

        setUser(data.data.user);
    };

    const logoutUser =
        async () => {

            await logout();

            setUser(null);

        };

    return (

        <AuthContext.Provider
            value={{
                user,
                loading,
                loginUser,
                logoutUser,
            }}
        >
            {children}
        </AuthContext.Provider>

    );

};

export const useAuth = () =>
    useContext(AuthContext);