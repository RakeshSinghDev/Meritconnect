import {
    CheckCircle,
    Download,
    Eye,
    Sparkles,
    XCircle,
} from "lucide-react";

import type { Application } from "../../types/application";

import CandidateScore from "./CandidateScore";
import ApplicationStatus from "./ApplicationStatus";

interface Props {
    applications: Application[];

    onStatusChange: (
        applicationId: string,
        status:
            | "Pending"
            | "Reviewed"
            | "Shortlisted"
            | "Rejected"
    ) => void;

    onView?: (id: string) => void;

    onResume?: (id: string) => void;

    onAIAnalysis?: (id: string) => void;
}

const ApplicationTable = ({
    applications,
    onStatusChange,
    onView,
    onResume,
    onAIAnalysis,
}: Props) => {
    return (
        <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white">

            <table className="min-w-full">

                <thead className="bg-gray-50">

                    <tr className="border-b text-left text-sm font-semibold">

                        <th className="px-6 py-4">Candidate</th>

                        <th className="px-6 py-4">Email</th>

                        <th className="px-6 py-4">AI Score</th>

                        <th className="px-6 py-4">Status</th>

                        <th className="px-6 py-4">
                            Actions
                        </th>

                    </tr>

                </thead>

                <tbody>

                    {applications.map((application) => (

                        <tr
                            key={application.id}
                            className="border-b last:border-none"
                        >
                            <td className="px-6 py-5">

                                <div>

                                    <p className="font-semibold">
                                        {application.candidateName}
                                    </p>

                                    <p className="text-sm text-gray-500">
                                        {application.phone}
                                    </p>

                                </div>

                            </td>

                            <td className="px-6 py-5">
                                {application.email}
                            </td>

                            <td className="px-6 py-5">

                                <CandidateScore
                                    score={application.score}
                                />

                            </td>

                            <td className="px-6 py-5">

                                <ApplicationStatus
                                    status={application.status}
                                />

                            </td>

                            <td className="px-6 py-5">

                                <div className="flex flex-wrap gap-2">

                                    <button
                                        onClick={() =>
                                            onView?.(
                                                application.id
                                            )
                                        }
                                        className="rounded-lg border p-2 hover:bg-gray-100"
                                    >
                                        <Eye size={18} />
                                    </button>

                                    <button
                                        onClick={() =>
                                            onResume?.(
                                                application.id
                                            )
                                        }
                                        className="rounded-lg border p-2 hover:bg-gray-100"
                                    >
                                        <Download size={18} />
                                    </button>

                                    <button
                                        onClick={() =>
                                            onAIAnalysis?.(
                                                application.id
                                            )
                                        }
                                        className="rounded-lg border p-2 hover:bg-gray-100"
                                    >
                                        <Sparkles size={18} />
                                    </button>

                                    <button
                                        onClick={() =>
                                            onStatusChange(
                                                application.id,
                                                "Shortlisted"
                                            )
                                        }
                                        className="rounded-lg bg-green-500 p-2 text-white"
                                    >
                                        <CheckCircle
                                            size={18}
                                        />
                                    </button>

                                    <button
                                        onClick={() =>
                                            onStatusChange(
                                                application.id,
                                                "Rejected"
                                            )
                                        }
                                        className="rounded-lg bg-red-500 p-2 text-white"
                                    >
                                        <XCircle
                                            size={18}
                                        />
                                    </button>

                                </div>

                            </td>

                        </tr>

                    ))}

                </tbody>

            </table>

        </div>
    );
};

export default ApplicationTable;