import { Calendar, MapPin, Pencil, Trash2 } from "lucide-react";
import type { Job } from "../../types/job";
import JobStatusBadge from "./JobStatusBadge";

interface Props {
    job: Job;
    onEdit: (job: Job) => void;
    onDelete: (id: string) => void;
}

const JobCard = ({ job, onEdit, onDelete }: Props) => {
    return (
        <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm transition hover:shadow-md">

            <div className="flex items-start justify-between">

                <div>
                    <h2 className="text-xl font-semibold">
                        {job.title}
                    </h2>

                    <p className="mt-1 text-gray-500">
                        {job.company}
                    </p>
                </div>

                <JobStatusBadge status={job.status} />
            </div>

            <div className="mt-5 flex flex-wrap gap-5 text-sm text-gray-500">

                <span className="flex items-center gap-2">
                    <MapPin size={16} />
                    {job.location}
                </span>

                <span>{job.employmentType}</span>

                <span>{job.salary}</span>

                <span className="flex items-center gap-2">
                    <Calendar size={16} />
                    {new Date(job.createdAt).toLocaleDateString()}
                </span>

            </div>

            <p className="mt-5 line-clamp-3 text-gray-600">
                {job.description}
            </p>

            <div className="mt-6 flex gap-3">

                <button
                    onClick={() => onEdit(job)}
                    className="flex items-center gap-2 rounded-lg border border-gray-300 px-4 py-2 transition hover:bg-gray-100"
                >
                    <Pencil size={16} />
                    Edit
                </button>

                <button
                    onClick={() => onDelete(job.id)}
                    className="flex items-center gap-2 rounded-lg bg-red-500 px-4 py-2 text-white transition hover:bg-red-600"
                >
                    <Trash2 size={16} />
                    Delete
                </button>

            </div>

        </div>
    );
};

export default JobCard;