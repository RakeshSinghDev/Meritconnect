import api from "../lib/api";

export const login = async (data: {
    email: string;
    password: string;
}) => {
    console.log("Calling API...");

    const response = await api.post("/auth/login", data);

    console.log("Response:", response);

    return response.data;
};

export const register = async (data: {
    name: string;
    email: string;
    password: string;
    role: "candidate" | "recruiter";
}) => {
    const response = await api.post("/auth/register", data);

    return response.data;
};

export const me = async () => {
    const response = await api.get("/auth/me");

    return response.data;
};

export const logout = async () => {
    const response = await api.post("/auth/logout");

    return response.data;
};