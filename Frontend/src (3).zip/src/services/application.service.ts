import api from "../lib/api";

import type { Application } from "../types/application";

export const applyJob = async (
    jobId: string,
    payload: FormData
): Promise<Application> => {
    const { data } = await api.post(
        `/applications/${jobId}`,
        payload,
        {
            headers: {
                "Content-Type":
                    "multipart/form-data",
            },
        }
    );

    return data.data;
};

export const getMyApplications = async (): Promise<
    Application[]
> => {
    const { data } = await api.get(
        "/applications/my-applications"
    );

    return data.data;
};

export const getJobApplications = async (
    jobId: string
): Promise<Application[]> => {
    const { data } = await api.get(
        `/applications/job/${jobId}`
    );

    return data.data;
};

export const getApplicationById = async (
    id: string
): Promise<Application> => {
    const { data } = await api.get(
        `/applications/${id}`
    );

    return data.data;
};

export const updateApplicationStatus = async (
    applicationId: string,
    status: string
): Promise<Application> => {
    const { data } = await api.patch(
        `/applications/${applicationId}/status`,
        { status }
    );

    return data.data;
};

export const getApplicationActivity = async (
    id: string
): Promise<any> => {
    const { data } = await api.get(
        `/applications/${id}/activity`
    );

    return data.data;
};