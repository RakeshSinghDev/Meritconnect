import { createBrowserRouter } from "react-router-dom";

import ProtectedRoute from "../routes/ProtectedRoute";

import HomePage from "../pages/HomePage";
import Login from "../pages/auth/Login";
import Register from "../pages/auth/Register";

import DashboardLayout from "../layouts/DashboardLayout";
import CandidateLayout from "../layouts/CandidateLayout";

import Dashboard from "../pages/recruiter/Dashboard";
import Jobs from "../pages/recruiter/Jobs";
import Applications from "../pages/recruiter/Applications";
import Candidates from "../pages/recruiter/Candidates";
import CandidateDetails from "../pages/recruiter/CandidateDetails";
import Interviews from "../pages/recruiter/Interviews";
import Analytics from "../pages/recruiter/Analytics";
import Settings from "../pages/recruiter/Settings";

import CandidateJobs from "../pages/candidate/Jobs";
import JobDetails from "../pages/candidate/JobDetails";
import ApplyJob from "../pages/candidate/ApplyJob";

export const router = createBrowserRouter([
    {
        path: "/",
        element: <HomePage />,
    },

    {
        path: "/login",
        element: <Login />,
    },

    {
        path: "/register",
        element: <Register />,
    },

    {
        element: <ProtectedRoute role="recruiter" />,
        children: [
            {
                path: "/recruiter",
                element: <DashboardLayout />,
                children: [
                    {
                        path: "dashboard",
                        element: <Dashboard />,
                    },
                    {
                        path: "jobs",
                        element: <Jobs />,
                    },
                    {
                        path: "applications",
                        element: <Applications />,
                    },
                    {
                        path: "candidates",
                        element: <Candidates />,
                    },
                    {
                        path: "candidates/:applicationId",
                        element: <CandidateDetails />,
                    },
                    {
                        path: "interviews",
                        element: <Interviews />,
                    },
                    {
                        path: "analytics",
                        element: <Analytics />,
                    },
                    {
                        path: "settings",
                        element: <Settings />,
                    },
                ],
            },
        ],
    },

    {
        element: <ProtectedRoute role="candidate" />,
        children: [
            {
                element: <CandidateLayout />,
                children: [
                    {
                        path: "/candidate/jobs",
                        element: <CandidateJobs />,
                    },
                    {
                        path: "/candidate/jobs/:id",
                        element: <JobDetails />,
                    },
                    {
                        path: "/candidate/jobs/:id/apply",
                        element: <ApplyJob />,
                    },
                ],
            },
        ],
    },
]);