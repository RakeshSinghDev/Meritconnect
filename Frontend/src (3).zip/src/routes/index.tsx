import { createBrowserRouter } from "react-router-dom";

import ProtectedRoute from "./ProtectedRoute";

import DashboardLayout from "../layouts/DashboardLayout";
import CandidateLayout from "../layouts/CandidateLayout";

import Login from "../pages/auth/Login";
import Register from "../pages/auth/Register";

import Dashboard from "../pages/recruiter/Dashboard";
import Jobs from "../pages/recruiter/Jobs";
import Applications from "../pages/recruiter/Applications";
import CandidateDetails from "../pages/recruiter/CandidateDetails";

import CandidateJobs from "../pages/candidate/Jobs";
import JobDetails from "../pages/candidate/JobDetails";
import ApplyJob from "../pages/candidate/ApplyJob";

export const router = createBrowserRouter([
    // =========================
    // Public Routes
    // =========================
    {
        path: "/login",
        element: <Login />,
    },

    {
        path: "/register",
        element: <Register />,
    },

    // =========================
    // Recruiter Routes
    // =========================
    {
        element: <ProtectedRoute role="recruiter" />,
        children: [
            {
                element: <DashboardLayout />,
                children: [
                    {
                        path: "/recruiter/dashboard",
                        element: <Dashboard />,
                    },
                    {
                        path: "/recruiter/jobs",
                        element: <Jobs />,
                    },
                    {
                        path: "/recruiter/applications",
                        element: <Applications />,
                    },
                    {
                        path: "/recruiter/candidates/:applicationId",
                        element: <CandidateDetails />,
                    },
                ],
            },
        ],
    },

    // =========================
    // Candidate Routes
    // =========================
    {
        element: <ProtectedRoute role="candidate" />,
        children: [
            {
                element: <CandidateLayout />,
                children: [
                    {
                        path: "/candidate/jobs",
                        element: <CandidateJobs />,
                    },
                    {
                        path: "/candidate/jobs/:id",
                        element: <JobDetails />,
                    },
                    {
                        path: "/candidate/jobs/:id/apply",
                        element: <ApplyJob />,
                    },
                ],
            },
        ],
    },

    // =========================
    // 404 Route
    // =========================
    {
        path: "*",
        element: (
            <div className="flex min-h-screen items-center justify-center">
                <h1 className="text-3xl font-bold">
                    404 | Page Not Found
                </h1>
            </div>
        ),
    },
]);