export interface Job {
    id: string;
    title: string;
    company: string;
    location: string;
    employmentType: string;
    salary: string;
    description: string;
    status: "Active" | "Closed";
    createdAt: string;
}