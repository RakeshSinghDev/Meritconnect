import { useEffect, useState } from "react";

import Drawer from "../../components/ui/Drawer";

import EmptyJobs from "../../components/jobs/EmptyJobs";
import JobFilters from "../../components/jobs/JobFilters";
import JobForm from "../../components/jobs/JobForm";
import JobCard from "../../components/jobs/JobCard";

import type { Job } from "../../types/job";

const Jobs = () => {
    const [open, setOpen] = useState(false);

    const [jobs, setJobs] = useState<Job[]>(() => {
        const saved = localStorage.getItem("jobs");
        return saved ? JSON.parse(saved) : [];
    });

    useEffect(() => {
        localStorage.setItem("jobs", JSON.stringify(jobs));
    }, [jobs]);

    const hasJobs = jobs.length > 0;

    return (
        <>
            <div className="mb-10 flex items-center justify-between">
                <div>
                    <h1 className="text-4xl font-bold">
                        Jobs
                    </h1>

                    <p className="mt-2 text-gray-500">
                        Manage all your job postings.
                    </p>
                </div>

                <button
                    onClick={() => setOpen(true)}
                    className="rounded-lg bg-black px-4 py-2 text-white"
                >
                    Create Job
                </button>
            </div>

            <JobFilters />

            {hasJobs ? (
                <div className="grid gap-6">
                    {jobs.map((job) => (
                        <JobCard
                            key={job.id}
                            job={job}
                        />
                    ))}
                </div>
            ) : (
                <EmptyJobs onCreateJob={() => setOpen(true)} />
            )}

            <Drawer
                open={open}
                title="Create New Job"
                onClose={() => setOpen(false)}
            >
                <JobForm
                    onCancel={() => setOpen(false)}
                    onSubmit={(job) => {
                        setJobs((prev) => [
                            ...prev,
                            {
                                id: crypto.randomUUID(),
                                status: "Active",
                                createdAt: new Date().toISOString(),
                                ...job,
                            },
                        ]);

                        setOpen(false);
                    }}
                />
            </Drawer>
        </>
    );
};

export default Jobs;