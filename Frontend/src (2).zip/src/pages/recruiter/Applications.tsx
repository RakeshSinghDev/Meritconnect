import Button from "../../components/ui/Button";
import ApplicationFilters from "../../components/applications/ApplicationFilters";
import EmptyApplications from "../../components/applications/EmptyApplications";

const Applications = () => {

    const hasApplications = false;

    return (

        <>

            <div className="mb-10 flex items-center justify-between">

                <div>

                    <h1 className="text-4xl font-bold">
                        Applications
                    </h1>

                    <p className="mt-2 text-gray-500">
                        Track every candidate who has applied for your jobs.
                    </p>

                </div>

                <Button>
                    Export
                </Button>

            </div>

            <ApplicationFilters />

            {hasApplications ? (
                <></>
            ) : (
                <EmptyApplications />
            )}

        </>

    );

};

export default Applications;