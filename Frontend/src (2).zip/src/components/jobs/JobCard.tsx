import type { Job } from "../../types/job";

interface Props {
    job: Job;
}

const JobCard = ({ job }: Props) => {
    return (
        <div className="rounded-3xl border border-gray-200 bg-white p-6">
            <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">
                    {job.title}
                </h2>

                <span className="rounded-full bg-green-100 px-3 py-1 text-sm text-green-700">
                    {job.status}
                </span>
            </div>

            <p className="mt-2 text-gray-500">
                {job.company}
            </p>

            <div className="mt-5 flex gap-6 text-sm text-gray-500">
                <span>{job.location}</span>
                <span>{job.employmentType}</span>
                <span>{job.salary}</span>
            </div>
        </div>
    );
};

export default JobCard;