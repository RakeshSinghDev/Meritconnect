import { useState } from "react";
import Button from "../ui/Button";

interface JobFormData {
    title: string;
    company: string;
    location: string;
    employmentType: string;
    salary: string;
    description: string;
}

interface Props {
    onSubmit: (job: JobFormData) => void;
    onCancel: () => void;
}

const JobForm = ({ onSubmit, onCancel }: Props) => {
    const [form, setForm] = useState<JobFormData>({
        title: "",
        company: "",
        location: "",
        employmentType: "Full Time",
        salary: "",
        description: "",
    });

    const handleChange = (
        e: React.ChangeEvent<
            HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
        >
    ) => {
        setForm((prev) => ({
            ...prev,
            [e.target.name]: e.target.value,
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(form);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <div>
                <label className="mb-2 block text-sm font-medium">
                    Job Title
                </label>

                <input
                    name="title"
                    value={form.title}
                    onChange={handleChange}
                    placeholder="Frontend Developer"
                    className="w-full rounded-xl border border-gray-200 p-3 outline-none focus:border-black"
                />
            </div>

            <div>
                <label className="mb-2 block text-sm font-medium">
                    Company
                </label>

                <input
                    name="company"
                    value={form.company}
                    onChange={handleChange}
                    placeholder="MeritConnect"
                    className="w-full rounded-xl border border-gray-200 p-3 outline-none focus:border-black"
                />
            </div>

            <div className="grid grid-cols-2 gap-5">
                <div>
                    <label className="mb-2 block text-sm font-medium">
                        Location
                    </label>

                    <input
                        name="location"
                        value={form.location}
                        onChange={handleChange}
                        placeholder="Remote"
                        className="w-full rounded-xl border border-gray-200 p-3 outline-none focus:border-black"
                    />
                </div>

                <div>
                    <label className="mb-2 block text-sm font-medium">
                        Employment Type
                    </label>

                    <select
                        name="employmentType"
                        value={form.employmentType}
                        onChange={handleChange}
                        className="w-full rounded-xl border border-gray-200 p-3"
                    >
                        <option>Full Time</option>
                        <option>Internship</option>
                        <option>Contract</option>
                    </select>
                </div>
            </div>

            <div>
                <label className="mb-2 block text-sm font-medium">
                    Salary
                </label>

                <input
                    name="salary"
                    value={form.salary}
                    onChange={handleChange}
                    placeholder="₹8–12 LPA"
                    className="w-full rounded-xl border border-gray-200 p-3 outline-none focus:border-black"
                />
            </div>

            <div>
                <label className="mb-2 block text-sm font-medium">
                    Description
                </label>

                <textarea
                    name="description"
                    value={form.description}
                    onChange={handleChange}
                    rows={6}
                    className="w-full rounded-xl border border-gray-200 p-3 outline-none focus:border-black"
                />
            </div>

            <div className="flex justify-end gap-3">
                <Button
                    type="button"
                    variant="outline"
                    onClick={onCancel}
                >
                    Cancel
                </Button>

                <Button type="submit">
                    Create Job
                </Button>
            </div>
        </form>
    );
};

export default JobForm;